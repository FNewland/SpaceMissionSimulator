#!/usr/bin/env bash
# =============================================================================
# SMO Suite — Clean Installation Script
# =============================================================================
# Run this script once on each machine to set up the environment.
# It creates a virtual environment, installs all dependencies, and verifies
# that everything works.
#
# Requirements:
#   - Python 3.11+ (python3.11 or python3)
#   - pip (bundled with Python 3.11+)
#   - Internet access (for downloading Python packages)
#
# Usage:
#   chmod +x install.sh
#   ./install.sh              # Install everything
#   ./install.sh --sim-only   # Install only simulator components
#   ./install.sh --mcs-only   # Install only MCS components
#   ./install.sh --plan-only  # Install only planner components
# =============================================================================
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_DIR"

# ── Color output ──
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

info()  { echo -e "${BLUE}[INFO]${NC}  $1"; }
ok()    { echo -e "${GREEN}[OK]${NC}    $1"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $1"; }
fail()  { echo -e "${RED}[FAIL]${NC}  $1"; exit 1; }

echo ""
echo "============================================="
echo "  SMO Suite — Installation"
echo "============================================="
echo "  Project: $PROJECT_DIR"
echo "============================================="
echo ""

# ── Parse arguments ──
INSTALL_MODE="all"
case "${1:-}" in
    --sim-only)  INSTALL_MODE="sim" ;;
    --mcs-only)  INSTALL_MODE="mcs" ;;
    --plan-only) INSTALL_MODE="plan" ;;
    --help|-h)
        echo "Usage: $0 [--sim-only | --mcs-only | --plan-only]"
        echo ""
        echo "  (no args)    Install all components"
        echo "  --sim-only   Install only simulator + common"
        echo "  --mcs-only   Install only MCS + common"
        echo "  --plan-only  Install only planner + common"
        exit 0
        ;;
esac

# ── Step 1: Find Python 3.11+ ──
info "Checking Python version..."
PYTHON=""
for candidate in python3.11 python3.12 python3.13 python3; do
    if command -v "$candidate" &>/dev/null; then
        ver=$("$candidate" -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")' 2>/dev/null || echo "0.0")
        major=$(echo "$ver" | cut -d. -f1)
        minor=$(echo "$ver" | cut -d. -f2)
        if [ "$major" -ge 3 ] && [ "$minor" -ge 11 ]; then
            PYTHON="$candidate"
            break
        fi
    fi
done

if [ -z "$PYTHON" ]; then
    fail "Python 3.11+ not found. Install it first:
    macOS:   brew install python@3.11
    Ubuntu:  sudo apt install python3.11 python3.11-venv
    Windows: Download from python.org"
fi
ok "Found $PYTHON ($($PYTHON --version))"

# ── Step 2: Create virtual environment ──
if [ -d ".venv" ]; then
    info "Virtual environment already exists at .venv"
    read -p "  Recreate it? (y/N) " -n 1 -r || REPLY="n"
    echo ""
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        info "Removing old .venv..."
        rm -rf .venv
        info "Creating new virtual environment..."
        "$PYTHON" -m venv .venv
        ok "Virtual environment created"
    else
        ok "Keeping existing .venv"
    fi
else
    info "Creating virtual environment..."
    "$PYTHON" -m venv .venv
    ok "Virtual environment created"
fi

# Activate
source .venv/bin/activate
ok "Virtual environment activated"

# ── Step 3: Upgrade pip ──
info "Upgrading pip..."
pip install --upgrade pip -q
ok "pip upgraded to $(pip --version | awk '{print $2}')"

# ── Step 4: Install packages ──
info "Installing SMO packages (mode: $INSTALL_MODE)..."

# Common is always needed
info "  Installing smo-common..."
pip install -e packages/smo-common -q
ok "  smo-common installed"

case "$INSTALL_MODE" in
    all)
        info "  Installing smo-simulator..."
        pip install -e packages/smo-simulator -q
        ok "  smo-simulator installed"

        info "  Installing smo-mcs..."
        pip install -e packages/smo-mcs -q
        ok "  smo-mcs installed"

        info "  Installing smo-planner..."
        pip install -e packages/smo-planner -q
        ok "  smo-planner installed"

        info "  Installing smo-gateway..."
        pip install -e packages/smo-gateway -q
        ok "  smo-gateway installed"
        ;;
    sim)
        info "  Installing smo-simulator..."
        pip install -e packages/smo-simulator -q
        ok "  smo-simulator installed"
        ;;
    mcs)
        info "  Installing smo-mcs..."
        pip install -e packages/smo-mcs -q
        ok "  smo-mcs installed"
        ;;
    plan)
        info "  Installing smo-planner..."
        pip install -e packages/smo-planner -q
        ok "  smo-planner installed"
        ;;
esac

# ── Step 5: Verify installation ──
info "Verifying installation..."
VERIFY_OK=true

if [ "$INSTALL_MODE" = "all" ] || [ "$INSTALL_MODE" = "sim" ]; then
    if command -v smo-simulator &>/dev/null; then
        ok "  smo-simulator command found"
    else
        warn "  smo-simulator command not found"
        VERIFY_OK=false
    fi
fi

if [ "$INSTALL_MODE" = "all" ] || [ "$INSTALL_MODE" = "mcs" ]; then
    if command -v smo-mcs &>/dev/null; then
        ok "  smo-mcs command found"
    else
        warn "  smo-mcs command not found"
        VERIFY_OK=false
    fi
fi

if [ "$INSTALL_MODE" = "all" ] || [ "$INSTALL_MODE" = "plan" ]; then
    if command -v smo-planner &>/dev/null; then
        ok "  smo-planner command found"
    else
        warn "  smo-planner command not found"
        VERIFY_OK=false
    fi
fi

if [ "$INSTALL_MODE" = "all" ]; then
    if command -v smo-gateway &>/dev/null; then
        ok "  smo-gateway command found"
    else
        warn "  smo-gateway command not found"
        VERIFY_OK=false
    fi
fi

# Verify config directory
if [ -d "configs/eosat1" ]; then
    ok "  Mission config directory found (configs/eosat1/)"
else
    warn "  Mission config directory not found"
    VERIFY_OK=false
fi

# ── Step 6: Verify Python imports ──
info "Verifying Python imports..."
python -c "import smo_common; print('  smo_common OK')" 2>/dev/null && ok "  smo_common imports" || warn "  smo_common import failed"

if [ "$INSTALL_MODE" = "all" ] || [ "$INSTALL_MODE" = "sim" ]; then
    python -c "import smo_simulator; print('  smo_simulator OK')" 2>/dev/null && ok "  smo_simulator imports" || warn "  smo_simulator import failed"
fi

# ── Step 7: Copy default env config if not present ──
if [ ! -f "$SCRIPT_DIR/smo-env.conf" ]; then
    warn "No smo-env.conf found — this should already be in the deploy/ directory"
fi

# ── Summary ──
echo ""
echo "============================================="
if [ "$VERIFY_OK" = true ]; then
    echo -e "  ${GREEN}Installation Complete${NC}"
else
    echo -e "  ${YELLOW}Installation Complete (with warnings)${NC}"
fi
echo "============================================="
echo ""
echo "  Next steps:"
echo ""
echo "  1. Edit deploy/smo-env.conf with your network settings"
echo ""
echo "  2. Start all services on this machine:"
echo "     ./deploy/start-all.sh"
echo ""
echo "  3. Or start individual components:"
echo "     ./deploy/start-simulator.sh"
echo "     ./deploy/start-mcs.sh"
echo "     ./deploy/start-planner.sh"
echo ""
echo "  4. Open in browser:"
echo "     MCS:        http://localhost:9090"
echo "     Planner:    http://localhost:9091"
echo "     Wide Plan:  http://localhost:9091/wide"
echo "     Instructor: http://localhost:8080"
echo ""
echo "============================================="
