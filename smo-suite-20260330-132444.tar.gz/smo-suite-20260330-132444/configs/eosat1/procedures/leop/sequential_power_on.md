# LEOP-007: Sequential Power-On

**Subsystem:** All
**Phase:** LEOP
**Revision:** 1.0
**Approved:** Flight Operations Director

## Purpose
Systematically power on each spacecraft subsystem, verify its telemetry,
and confirm nominal operation before proceeding to the next subsystem.

## Prerequisites
- [ ] Application software running (sw_image = 1)
- [ ] Onboard time set (S9.1 completed)
- [ ] Antennas deployed (antenna_deployed = 1)
- [ ] Full-rate link established
- [ ] All console positions staffed and nominal

## Procedure Steps

### Step 1 — Verify EPS Baseline
**Action:** EPS/TCS confirms battery SoC > 60%, bus voltage 27-29V.
**Verify:** `eps.bat_soc` (0x0101) > 60% within 10s
**Verify:** `eps.bus_voltage` (0x0105) in range [27.0V, 29.0V] within 10s
**Action:** EPS/TCS confirms solar array currents (sa_a_current, sa_b_current) are generating.
**Action:** FD records baseline power consumption (~50W: OBC + RX + TX).
**GO/NO-GO:** Proceed if SoC > 60% and bus voltage nominal

### Step 2 — Enable Battery Heater
**TC:** `POWER_LINE_ON(line=5)` (Service 8) — htr_bat
**Action:** EPS/TCS commands power_line_on for htr_bat (line index 5).
**Verify:** Battery temperature trending towards set point (5C) within 120s
**Verify:** Power consumption increased by ~6W within 30s
**Action:** FD records power margin.
**GO/NO-GO:** Battery heater active, power margin positive

### Step 3 — Enable AOCS Reaction Wheels
**TC:** `POWER_LINE_ON(line=7)` (Service 8) — aocs_wheels
**Action:** EPS/TCS commands power_line_on for aocs_wheels (line index 7).
**Verify:** Reaction wheel currents responding, all 4 wheels active within 30s
**TC:** `SET_AOCS_MODE(mode=1)` (Service 8) — DETUMBLE
**Action:** AOCS commands AOCS mode 1 (DETUMBLE). Monitor body rates decreasing.
**Verify:** `aocs.rate_roll` (0x0204) decreasing within 60s
**Verify:** `aocs.rate_pitch` (0x0205) decreasing within 60s
**Verify:** `aocs.rate_yaw` (0x0206) decreasing within 60s
**Verify:** Power consumption increased by ~12W within 30s
**GO/NO-GO:** Proceed when body rates < 0.5 deg/s

### Step 4 — Commission AOCS Sensors
**Action:** AOCS verifies magnetometer readings (mag_a_x/y/z).
**Verify:** `aocs.mag_a_x` (0x0200) responding with valid field data within 10s
**Action:** AOCS verifies coarse sun sensor readings (6 CSS heads).
**Action:** Wait for star camera acquisition (requires rates < 0.1 deg/s).
**TC:** `SET_AOCS_MODE(mode=2)` (Service 8) — SAFE/Sun-pointing
**Action:** AOCS commands AOCS mode 2 (SAFE/Sun-pointing) when sensors valid.
**Verify:** `aocs.att_error` (0x0217) decreasing within 120s
**GO/NO-GO:** Proceed when attitude error < 5 deg

### Step 5 — Enable Payload (Standby)
**TC:** `POWER_LINE_ON(line=3)` (Service 8) — payload
**Action:** EPS/TCS commands power_line_on for payload (line index 3).
**TC:** `SET_PAYLOAD_MODE(mode=1)` (Service 8) — STANDBY
**Action:** Payload commands payload mode 1 (STANDBY).
**Verify:** FPA temperature reading valid within 30s
**Verify:** Payload memory status nominal within 30s
**Verify:** Power consumption increased by ~8W within 30s
**Action:** FD records power margin.
**GO/NO-GO:** Payload powered and responding in standby

### Step 6 — Enable FPA Cooler
**TC:** `POWER_LINE_ON(line=4)` (Service 8) — fpa_cooler
**TC:** `SET_FPA_COOLER(on=1)` (Service 8)
**Action:** EPS/TCS commands power_line_on for fpa_cooler (line index 4) then activates cooler.
**Verify:** `payload.fpa_temp` (0x0600) decreasing towards -30C within 300s
**Verify:** Power consumption increased by ~15W within 30s
**GO/NO-GO:** Proceed when FPA temp < -25C

### Step 7 — Final Checkout
**Action:** FD initiates GO/NO-GO poll across all positions.
**Action:** All positions report subsystem status (nominal/degraded/failed).
**TC:** `SET_PHASE(phase=5)` (Service 8) — COMMISSIONING
**Action:** If all GO, FD commands transition to COMMISSIONING phase (phase 5).
**GO/NO-GO:** All positions report GO for commissioning transition

## Off-Nominal Handling
- If SoC drops below 40% at any point: STOP, shed last powered subsystem. Wait for battery charge recovery. Resume when SoC > 60%.
- If any subsystem fails to respond after power-on: Skip that subsystem, continue with remaining subsystems. Log failure for troubleshooting on subsequent pass.
- If bus voltage < 26V: Immediate load shed per CTG-001 (Under-Voltage Load Shed). Power off last enabled subsystem first, then proceed down priority list.
- If reaction wheels fail to spin up: Remain on magnetorquer-only detumble. Do not proceed to fine pointing modes. Schedule AOCS contingency investigation.
- If body rates do not decrease in DETUMBLE: Verify magnetorquer polarity. If rates increase, command AOCS mode 0 (OFF) immediately and investigate.

## Post-Conditions
- [ ] All subsystems powered and verified nominal
- [ ] Battery heater active, temperature trending to set point
- [ ] AOCS in SAFE mode (mode 2) with attitude error < 5 deg
- [ ] Payload powered in STANDBY mode
- [ ] FPA cooler active, temperature approaching operational range
- [ ] Power margin positive with all subsystems enabled
- [ ] Spacecraft transitioned to COMMISSIONING phase (phase 5)
- [ ] GO/NO-GO poll completed with all positions reporting GO
