# LEOP-001: First Acquisition of Signal
**Subsystem:** TT&C / Ground Segment
**Phase:** LEOP
**Revision:** 1.0
**Approved:** Flight Operations Director

## Purpose
Establish first radio contact with EOSAT-1 following separation from the launch vehicle.
Acquire S-band downlink, verify carrier lock, and receive initial housekeeping telemetry
to confirm spacecraft is alive and transmitting on the expected frequency.

## Prerequisites
- [ ] Launcher separation confirmed (launch provider telemetry)
- [ ] Svalbard ground station antenna configured for EOSAT-1 S-band receive frequency
- [ ] Predicted AOS/LOS timeline loaded into ground station schedule
- [ ] Flight Dynamics have provided initial TLE from launch provider
- [ ] Mission Control System (MCS) database loaded with EOSAT-1 TM/TC definitions
- [ ] All console positions staffed and nominal

## Procedure Steps

### Step 1 — Configure Ground Station Receiver
**Action:** Command Svalbard ground station to point at predicted AOS azimuth/elevation. Enable auto-tracking on S-band downlink frequency. Set receiver bandwidth to wide acquisition mode (+/- 40 kHz Doppler window).
**Verify:** Ground station status = TRACKING_READY
**GO/NO-GO:** Ground station locked on predicted trajectory

### Step 2 — Wait for Acquisition of Signal
**Action:** Monitor receiver spectrum display for carrier appearance at predicted AOS time. Allow up to +5 minutes beyond predicted AOS for timing uncertainty.
**Verify:** `ttc.rssi` (0x0502) > -110 dBm within 300s of predicted AOS
**GO/NO-GO:** If no signal at AOS +5 min, execute Off-Nominal Case 1

### Step 3 — Verify Carrier Lock
**Action:** Confirm ground station receiver has achieved carrier lock on S-band downlink. Record measured Doppler offset for Flight Dynamics.
**Verify:** `ttc.link_status` (0x0501) = 1 (LOCKED) within 30s of carrier detection
**Verify:** `ttc.link_margin` (0x0503) > 3.0 dB
**GO/NO-GO:** Stable carrier lock with positive link margin

### Step 4 — Establish Uplink and Verify Command Path
**TC:** `TTC_SWITCH_PRIMARY` (Service 11, Subtype 1)
**Action:** Transmit uplink carrier on S-band command frequency. Send TC verification ping.
**Verify:** `ttc.link_status` (0x0501) = 1 (LOCKED) maintained within 10s
**Verify:** TC acceptance acknowledgement received (Service 1, Subtype 1)
**GO/NO-GO:** Bidirectional link established

### Step 5 — Synchronize On-Board Time
**TC:** `SET_TIME(cuc_seconds)` (Service 9, Subtype 1)
**Action:** Upload current UTC epoch as CUC seconds to synchronize OBC clock. Use ground station time-stamped uplink for propagation delay correction.
**Verify:** `GET_PARAM(0x0300)` — `obdh.mode` (0x0300) responds with valid value within 5s
**GO/NO-GO:** Time synchronization accepted

### Step 6 — Request First Housekeeping Telemetry
**TC:** `HK_REQUEST(sid=1)` (Service 3, Subtype 27)
**Action:** Request SID 1 (EPS summary) to confirm spacecraft power state.
**Verify:** `eps.bus_voltage` (0x0105) in range [26.0V, 30.0V] within 10s
**Verify:** `eps.bat_soc` (0x0101) > 50%
**GO/NO-GO:** Valid telemetry received with plausible values

### Step 7 — Request Extended Housekeeping
**TC:** `HK_REQUEST(sid=2)` (Service 3, Subtype 27)
**TC:** `HK_REQUEST(sid=3)` (Service 3, Subtype 27)
**Action:** Request SID 2 (AOCS summary) and SID 3 (thermal summary) for initial state assessment.
**Verify:** `aocs.mode` (0x020F) = 1 (DETUMBLE) or 2 (SAFE_POINT) within 10s
**Verify:** `tcs.temp_obc` (0x0406) in range [-10C, +50C] within 10s
**GO/NO-GO:** All received telemetry within expected ranges

### Step 8 — Log and Report
**Action:** Record AOS time, measured RSSI, link margin, Doppler offset, and all received HK values. Distribute First Acquisition Report to mission team. Confirm pass duration sufficient for LEOP-002 or schedule next pass.
**GO/NO-GO:** Sufficient data collected for initial health assessment

## Off-Nominal Handling
- If no signal at AOS +5 min: Switch Svalbard to search mode (+/- 100 kHz). Alert Troll and Inuvik stations to prepare backup acquisition windows. Verify TLE accuracy with Flight Dynamics.
- If carrier detected but no TM lock: Increase receiver integration time. Check for frequency offset exceeding Doppler prediction. Try redundant receiver chain.
- If uplink not accepted: Verify uplink frequency and power settings. Attempt `TTC_SWITCH_REDUNDANT` via ground command on backup frequency.
- If telemetry values out of range: Record all values and proceed to LEOP-002 for detailed health assessment. Do not command mode changes until health check complete.
- If link margin < 3 dB: Note degradation, continue with reduced commanding rate. Schedule antenna re-pointing verification.

## Post-Conditions
- [ ] Bidirectional S-band link established with EOSAT-1
- [ ] On-board time synchronized to UTC
- [ ] Initial housekeeping telemetry received and recorded
- [ ] Bus voltage and battery SOC confirmed within nominal range
- [ ] AOCS mode confirmed (DETUMBLE or SAFE_POINT)
- [ ] First Acquisition Report distributed to mission team
