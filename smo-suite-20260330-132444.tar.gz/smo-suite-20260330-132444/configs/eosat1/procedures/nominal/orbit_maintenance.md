# PROC-NOM-003: Orbit Maintenance Manoeuvre
**Subsystem:** AOCS / Orbit Control
**Phase:** NOMINAL
**Revision:** 1.0
**Approved:** Flight Operations Director

## Purpose
Perform an orbit maintenance manoeuvre to correct altitude decay or ground track drift.
Upload and execute a pre-computed delta-V command sequence using the onboard thruster
system. EOSAT-1 requires periodic orbit maintenance (approximately every 30--60 days) to
remain within the mission orbit altitude corridor (+/- 5 km) and maintain the required
ground track repeatability for Earth observation coverage. The manoeuvre plan is computed
by Flight Dynamics based on GPS-derived orbit determination and propagated to the
required burn epoch, duration, and thrust vector.

## Prerequisites
- [ ] AOCS in NOMINAL (NADIR_POINT) mode: `aocs.mode` (0x020F) = 0
- [ ] Orbit determination performed by Flight Dynamics (GPS fix: `aocs.gps_fix` (0x0274) >= 2)
- [ ] Manoeuvre plan computed, reviewed, and signed off by Flight Dynamics team
- [ ] Payload stowed/OFF: `payload.mode` (0x0600) = 0 or 1 (not imaging)
- [ ] Battery SoC > 70 %: `eps.bat_soc` (0x0101) > 70
- [ ] Thruster heater active: `tcs.temp_thruster` (0x0409) > +5 C (propellant above freezing)
- [ ] No eclipse entry expected during burn window
- [ ] AOCS operator at console
- [ ] Flight Director has authorised the manoeuvre

## Procedure Steps

### Step 1 --- Pre-Manoeuvre Health Assessment
**TC:** `HK_REQUEST` SID=2 (Service 3, Subtype 25) --- request AOCS housekeeping
**Verify:** `aocs.mode` (0x020F) = 0 (NADIR_POINT)
**Verify:** `aocs.att_error` (0x0217) < 0.5 deg
**Verify:** `aocs.rate_roll` (0x0204) < 0.02 deg/s
**Verify:** `aocs.rate_pitch` (0x0205) < 0.02 deg/s
**Verify:** `aocs.rate_yaw` (0x0206) < 0.02 deg/s
**Verify:** All reaction wheels operational:
  - `aocs.rw1_speed` (0x0207) within +/- 5000 RPM
  - `aocs.rw2_speed` (0x0208) within +/- 5000 RPM
  - `aocs.rw3_speed` (0x0209) within +/- 5000 RPM
  - `aocs.rw4_speed` (0x020A) within +/- 5000 RPM
**TC:** `HK_REQUEST` SID=1 (Service 3, Subtype 25) --- request EPS housekeeping
**Verify:** `eps.bat_soc` (0x0101) > 70 %
**Verify:** `eps.bus_voltage` (0x0105) > 28.0 V
**TC:** `HK_REQUEST` SID=3 (Service 3, Subtype 25) --- request TCS housekeeping
**Verify:** `tcs.temp_thruster` (0x0409) > +5 C (propellant line above freezing)
**GO/NO-GO:** All subsystems nominal. Flight Director confirms GO for manoeuvre.

### Step 2 --- Configure AOCS for Manoeuvre Mode
**TC:** `FUNC_PERFORM` func_id=50 (Service 8, Subtype 1) --- configure AOCS manoeuvre mode
**Action:** Command the AOCS to transition from NADIR_POINT to MANOEUVRE mode. In this
mode, the AOCS maintains the thrust vector alignment computed by Flight Dynamics instead
of nadir pointing.
**Verify:** `aocs.mode` (0x020F) transitions to MANOEUVRE (4) within 10 s
**Verify:** `aocs.att_error` (0x0217) converges to < 1.0 deg on new reference frame
**Note:** The AOCS will use the reaction wheels to slew to the manoeuvre attitude. Allow
up to 120 s for the slew to complete.
**GO/NO-GO:** AOCS in MANOEUVRE mode with attitude error converging.

### Step 3 --- Upload Burn Parameters
**TC:** `FUNC_PERFORM` func_id=51, params=[epoch, duration, dV_x, dV_y, dV_z] (Service 8, Subtype 1) --- upload manoeuvre parameters
**Action:** Upload the following Flight Dynamics parameters:
  - Burn epoch: CUC time for thruster ignition
  - Burn duration: seconds (typically 5--60 s for maintenance burns)
  - Delta-V vector: [dV_x, dV_y, dV_z] in body frame (m/s)
**Verify:** Command acceptance within 5 s
**Verify:** Parameter echo-back matches commanded values (request via Service 3 if available)
**Note:** Double-check all parameters against the signed Flight Dynamics manoeuvre plan.
A wrong burn epoch or duration could result in an incorrect orbit.
**GO/NO-GO:** Burn parameters verified correct. AOCS ready for armed state.

### Step 4 --- Arm Thruster System
**TC:** `FUNC_PERFORM` func_id=52 (Service 8, Subtype 1) --- arm thruster for firing
**Verify:** Command acceptance within 5 s
**Verify:** `tcs.temp_thruster` (0x0409) > +5 C (re-confirm propellant temperature)
**Note:** The thruster system is now in armed state. The burn will execute automatically
at the commanded epoch. To abort at any time before ignition, send the DISARM command
(func_id=53).
**Caution:** Once armed, the burn is autonomous. Ground operators have approximately
T_epoch minus current_time seconds to abort if needed.
**GO/NO-GO:** Thruster armed. Flight Director gives final GO for autonomous burn execution.

### Step 5 --- Execute Manoeuvre (Autonomous at Epoch)
**TC:** `TIME_SCHEDULE` epoch=T_burn (Service 11, Subtype 4) --- schedule burn execution
**Action:** The onboard system will autonomously ignite the thruster at the commanded epoch.
Monitor telemetry throughout the burn window.
**Monitor:** `aocs.att_error` (0x0217) --- should remain < 2.0 deg during burn
**Monitor:** `aocs.rate_roll` (0x0204), `aocs.rate_pitch` (0x0205), `aocs.rate_yaw` (0x0206) ---
expect transient rates during burn, should remain < 1.0 deg/s
**Monitor:** `eps.power_cons` (0x0106) --- expect increase during thruster firing
**Monitor:** `eps.bat_soc` (0x0101) --- should not drop below 60 % during burn
**Verify:** Thruster firing confirmed via telemetry (power consumption spike, rate transients)
**Duration:** Monitor for full burn duration plus 30 s settling time.
**GO/NO-GO:** Burn execution confirmed via telemetry signatures.

### Step 6 --- Monitor Post-Burn Attitude and Rates
**TC:** `HK_REQUEST` SID=2 (Service 3, Subtype 25) --- request AOCS housekeeping
**Verify:** `aocs.rate_roll` (0x0204) < 0.1 deg/s (rates settling)
**Verify:** `aocs.rate_pitch` (0x0205) < 0.1 deg/s
**Verify:** `aocs.rate_yaw` (0x0206) < 0.1 deg/s
**Verify:** `aocs.att_error` (0x0217) converging toward < 1.0 deg
**Action:** Allow 120 s for the reaction wheels to absorb residual rates from the burn
and re-establish fine attitude control.
**Monitor:** All wheel speeds remain within operational limits (< 5500 RPM).
**GO/NO-GO:** Rates settling, attitude converging. No anomalous tumble.

### Step 7 --- Verify Post-Burn Orbit
**TC:** `HK_REQUEST` SID=2 (Service 3, Subtype 25) --- request AOCS with GPS data
**Verify:** `aocs.gps_fix` (0x0274) >= 2 (3D fix)
**Verify:** `aocs.gps_alt` (0x0212) within expected post-burn altitude corridor
**Action:** Record GPS position: lat=`aocs.gps_lat` (0x0210), lon=`aocs.gps_lon` (0x0211),
alt=`aocs.gps_alt` (0x0212).
**Action:** Downlink GPS ephemeris data to Flight Dynamics for post-burn orbit determination.
**Note:** Precise orbit determination will take 2--3 orbits of GPS data collection.
Preliminary altitude check is performed here for immediate assessment.
**GO/NO-GO:** GPS fix acquired. Preliminary altitude consistent with planned delta-V.

### Step 8 --- Return to NOMINAL Mode and Log Results
**TC:** `AOCS_SET_MODE` mode=0 (Service 8, Subtype 1) --- command NADIR_POINT
**Verify:** `aocs.mode` (0x020F) = 0 (NADIR_POINT) within 15 s
**Verify:** `aocs.att_error` (0x0217) < 0.5 deg within 120 s
**TC:** `FUNC_PERFORM` func_id=53 (Service 8, Subtype 1) --- disarm thruster (safe state)
**Verify:** Command acceptance within 5 s
**Action:** Log manoeuvre results:
  - Burn epoch (planned vs actual)
  - Burn duration (planned vs actual)
  - Planned delta-V vs estimated achieved delta-V
  - Pre/post-burn GPS altitudes
  - Maximum attitude error and body rates during burn
  - Battery SoC consumed during manoeuvre
  - Any anomalies observed
**Note:** Flight Dynamics will provide refined orbit determination within 24 hours.
A trim manoeuvre may be required if the achieved delta-V differs from plan by > 5 %.
**GO/NO-GO:** Spacecraft returned to NADIR_POINT. Manoeuvre procedure complete.

## Off-Nominal Handling
- If AOCS does not transition to MANOEUVRE mode: Re-send command. If still no transition,
  verify no FDIR flag is inhibiting mode changes. Abort manoeuvre, remain in NADIR_POINT.
- If burn does not ignite at epoch: Verify thruster arm status. Check `tcs.temp_thruster`
  (0x0409) --- propellant may have cooled below minimum. Check for onboard FDIR inhibit.
  Disarm thruster, investigate, and reschedule burn for next opportunity.
- If attitude error exceeds 5 deg during burn: Possible thruster misalignment or single-
  thruster failure. The burn may have imparted unplanned torque. Allow AOCS to recover
  in MANOEUVRE mode. If rates exceed 2 deg/s, command DETUMBLE (mode=1) immediately.
- If battery SoC drops below 55 % during burn: Abort burn immediately via
  `FUNC_PERFORM` func_id=53 (disarm). Partial delta-V is preferable to power emergency.
  A correction manoeuvre can be scheduled for the next opportunity.
- If GPS fix lost after burn: Wait up to 2 orbits for GPS re-acquisition. Use ground
  tracking (radar) as backup orbit determination source.
- If post-burn altitude is significantly different from plan (> 2 km error): Flight
  Dynamics to assess whether a correction burn is needed urgently or can be deferred.

## Post-Conditions
- [ ] AOCS returned to NADIR_POINT mode: `aocs.mode` (0x020F) = 0
- [ ] Attitude error < 0.5 deg: `aocs.att_error` (0x0217) < 0.5
- [ ] Body rates < 0.02 deg/s on all axes
- [ ] Thruster system disarmed and safed
- [ ] GPS fix re-acquired for post-burn orbit determination
- [ ] Battery SoC > 60 %: `eps.bat_soc` (0x0101) > 60
- [ ] Manoeuvre log completed with all parameters recorded
- [ ] Flight Dynamics notified to begin post-burn orbit determination
- [ ] Spacecraft ready to resume nominal imaging and downlink operations

---
*AIG --- Artificial Intelligence Generated Content*
*Reference: https://mpeters.uqo.ca/en/logos-ia-en-peters-2023/*
