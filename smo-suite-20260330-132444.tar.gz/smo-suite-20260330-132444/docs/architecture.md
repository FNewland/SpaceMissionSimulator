# Space Mission Operations Suite — Architecture

## Overview
The SMO suite consists of 4 main tools plus shared infrastructure:

1. **Spacecraft Simulator** (`smo-simulator`) — config-driven spacecraft simulation
2. **Mission Control System** (`smo-mcs`) — operator displays and commanding
3. **Mission Planning Tool** (`smo-planner`) — orbit prediction and scheduling
4. **Network Gateway** (`smo-gateway`) — TM/TC relay for distributed deployment

## Shared Infrastructure
- **Common Library** (`smo-common`) — protocol, config schemas, orbit utilities
- **EOSAT-1 Config** (`configs/eosat1/`) — complete mission configuration

## Key Design Principles
- **Config-driven**: All spacecraft parameters, displays, and behaviors defined in YAML
- **Plugin architecture**: Subsystem models loaded via Python entry points
- **ECSS PUS-C compliant**: Standard space packet protocol throughout
- **Distributed-ready**: Gateway enables multi-machine deployment

## Network Architecture
```
Single machine:  [Simulator] <-TCP-> [MCS] <-WebSocket-> [Browser]
Distributed:     [Simulator] <-TCP-> [Gateway] <-TCP-> [MCS instances]
```

## Technology Stack
- Python 3.11+, Pydantic v2, aiohttp, asyncio, sgp4, numpy
