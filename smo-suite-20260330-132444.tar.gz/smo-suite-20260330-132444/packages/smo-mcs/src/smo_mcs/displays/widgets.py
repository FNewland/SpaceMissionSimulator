"""SMO MCS — Display Widgets.

Reusable display widget definitions for MCS operator positions.
"""
from typing import Any


class Widget:
    """Base class for display widgets."""
    widget_type: str = "base"

    def render(self, value: Any, config: dict) -> dict:
        return {"type": self.widget_type, "value": value}


class GaugeWidget(Widget):
    widget_type = "gauge"

    def render(self, value: float, config: dict) -> dict:
        return {
            "type": "gauge",
            "value": round(value, 2),
            "label": config.get("label", ""),
            "range": config.get("range", [0, 100]),
            "units": config.get("units", ""),
        }


class LineChartWidget(Widget):
    widget_type = "line_chart"

    def render(self, values: dict[str, list[float]], config: dict) -> dict:
        return {
            "type": "line_chart",
            "series": values,
            "label": config.get("label", ""),
            "duration_s": config.get("duration_s", 600),
        }


class ValueTableWidget(Widget):
    widget_type = "value_table"

    def render(self, params: dict[str, float], config: dict) -> dict:
        return {
            "type": "value_table",
            "parameters": params,
        }


class StatusIndicatorWidget(Widget):
    widget_type = "status_indicator"

    def render(self, value: Any, config: dict) -> dict:
        return {
            "type": "status_indicator",
            "active": bool(value),
            "label": config.get("label", ""),
        }


class EventLogWidget(Widget):
    widget_type = "event_log"

    def render(self, events: list[dict], config: dict) -> dict:
        return {
            "type": "event_log",
            "events": events[-50:],  # last 50
        }
