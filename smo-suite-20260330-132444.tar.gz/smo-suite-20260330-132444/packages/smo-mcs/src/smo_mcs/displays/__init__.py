"""SMO MCS — Display engine."""
