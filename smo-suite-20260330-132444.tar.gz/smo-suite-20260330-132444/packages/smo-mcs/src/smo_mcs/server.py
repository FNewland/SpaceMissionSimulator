"""SMO MCS — Web Server.

Connects to simulator/gateway via TCP, serves config-driven operator displays.
Supports position-based command access control.
"""
import asyncio
import json
import logging
import struct
import argparse
import time as _time_mod
from pathlib import Path
from typing import Any, Optional
from collections import deque

import aiohttp
from aiohttp import web

from smo_common.protocol.framing import frame_packet, read_framed_packet
from smo_common.protocol.ecss_packet import decommutate_packet
from smo_common.config.loader import (
    load_mcs_displays, load_mission_config, load_positions, load_tc_catalog,
)
from smo_mcs.tc_manager import TCManager
from smo_mcs.procedure_runner import ProcedureRunner
from smo_mcs.tm_archive import TMArchive

logger = logging.getLogger(__name__)


class MCSServer:
    """Mission Control System web server."""

    def __init__(self, config_dir: str | Path, connect_host: str = "localhost",
                 connect_port: int = 8002, http_port: int = 9090,
                 sim_http_port: int = 8080, tc_port: int = 8001):
        self.config_dir = Path(config_dir)
        self.connect_host = connect_host
        self.connect_port = connect_port
        self.http_port = http_port
        self.tc_port = tc_port
        self.sim_api_base = f"http://{connect_host}:{sim_http_port}"
        self.sim_api_url = f"{self.sim_api_base}/api/mcs-state"
        self._ws_clients: list[tuple[web.WebSocketResponse, str]] = []
        self._latest_state: dict = {}
        self._running = False
        self._displays = load_mcs_displays(self.config_dir)

        # Position access control
        self._positions = load_positions(self.config_dir)

        # TC catalog for command metadata
        try:
            self._tc_catalog = load_tc_catalog(self.config_dir)
        except Exception:
            self._tc_catalog = []

        # TC connection
        self._tc_writer: Optional[asyncio.StreamWriter] = None
        self._tc_manager = TCManager(apid=1)

        # Verification log — last 200 commands
        self._verification_log: deque[dict] = deque(maxlen=200)

        # Shift handover log
        self._handover_log: list[dict] = []

        # GO/NO-GO coordination state
        self._go_nogo_active = False
        self._go_nogo_label = ""
        self._go_nogo_responses: dict[str, str] = {}  # position -> GO/NOGO/STANDBY
        self._go_nogo_initiator = ""

        # Procedure execution engine
        self._procedure_runner = ProcedureRunner(
            send_command_fn=self._proc_send_command,
            get_telemetry_fn=self._proc_get_telemetry,
        )

        # Load activity types for procedure browser
        self._activity_types: list[dict] = []
        try:
            import yaml
            at_path = self.config_dir / "planning" / "activity_types.yaml"
            if at_path.exists():
                with open(at_path) as f:
                    data = yaml.safe_load(f)
                self._activity_types = data.get("activity_types", [])
        except Exception:
            pass

        # Alarm journal — last 1000 alarms (Feature 2)
        self._alarm_journal: deque[dict] = deque(maxlen=1000)
        self._alarm_id_counter = 0

        # Persistent TM archive (SQLite)
        archive_dir = self.config_dir / ".." / "data"
        archive_dir.mkdir(parents=True, exist_ok=True)
        self._archive = TMArchive(archive_dir / "tm_archive.db")
        self._archive.open()
        self._archive_tick = 0  # counter to batch parameter archiving

        # TM dump playback data (Feature 3)
        self._tm_dump_data: dict[str, list[dict]] = {}

        # Planner API base URL for contacts proxy (Feature 1)
        # Prefer SMO_PLANNER_URL env var for distributed deployments
        import os
        self._planner_api_base = os.environ.get(
            "SMO_PLANNER_URL", f"http://{connect_host}:9091"
        )

        # Load procedure index for procedure browser
        self._procedure_index: list[dict] = []
        try:
            import yaml
            pi_path = self.config_dir / "procedures" / "procedure_index.yaml"
            if pi_path.exists():
                with open(pi_path) as f:
                    data = yaml.safe_load(f)
                self._procedure_index = data.get("procedures", [])
        except Exception:
            pass

    def _check_position_access(self, position: str, service: int,
                               subtype: int, data_hex: str) -> tuple[bool, str]:
        """Check if the given position is allowed to send this command.

        Returns (allowed, reason).
        """
        if not self._positions:
            return True, ""  # No position config loaded

        pos_config = self._positions.get(position)
        if pos_config is None:
            return True, ""  # Unknown position, allow by default

        # "all" positions bypass
        if pos_config.allowed_commands == "all":
            return True, ""

        # Check service access
        if pos_config.allowed_services and service not in pos_config.allowed_services:
            return False, f"Service {service} not allowed for position {position}"

        # For S8 commands, also check func_id
        if service == 8 and subtype == 1 and data_hex:
            try:
                data_bytes = bytes.fromhex(data_hex)
                if data_bytes:
                    func_id = data_bytes[0]
                    if pos_config.allowed_func_ids and func_id not in pos_config.allowed_func_ids:
                        return False, f"Function {func_id} not allowed for position {position}"
            except (ValueError, IndexError):
                pass

        return True, ""

    async def start(self) -> None:
        self._running = True
        app = web.Application()
        app.router.add_get("/", self._handle_index)
        app.router.add_get("/ws", self._handle_ws)
        app.router.add_get("/api/displays", self._handle_displays)
        app.router.add_get("/api/state", self._handle_state)
        app.router.add_get("/api/sim-state", self._handle_sim_state)
        app.router.add_post("/api/command", self._handle_command)
        app.router.add_post("/api/pus-command", self._handle_pus_command)
        app.router.add_get("/api/verification-log", self._handle_verification_log)
        app.router.add_get("/api/procedures", self._handle_procedures_list)
        app.router.add_get("/api/procedures/{path:.+}", self._handle_procedure_file)
        app.router.add_get("/api/manual", self._handle_manual_list)
        app.router.add_get("/api/manual/{path:.+}", self._handle_manual_file)
        app.router.add_get("/api/positions", self._handle_positions)
        app.router.add_get("/api/tc-catalog", self._handle_tc_catalog)
        # Procedure execution endpoints
        app.router.add_post("/api/procedure/load", self._handle_proc_load)
        app.router.add_post("/api/procedure/start", self._handle_proc_start)
        app.router.add_post("/api/procedure/pause", self._handle_proc_pause)
        app.router.add_post("/api/procedure/resume", self._handle_proc_resume)
        app.router.add_post("/api/procedure/abort", self._handle_proc_abort)
        app.router.add_post("/api/procedure/step", self._handle_proc_step)
        app.router.add_post("/api/procedure/skip", self._handle_proc_skip)
        app.router.add_get("/api/procedure/status", self._handle_proc_status)
        app.router.add_post("/api/procedure/override-command", self._handle_proc_override)
        app.router.add_get("/api/procedure/activity-types", self._handle_activity_types)
        app.router.add_get("/api/procedure/index", self._handle_proc_index)
        # Procedure builder save/load
        app.router.add_post("/api/procedure/save", self._handle_proc_save)
        app.router.add_get("/api/procedure/custom", self._handle_proc_custom_list)
        # GO/NO-GO coordination
        app.router.add_get("/api/go-nogo/status", self._handle_go_nogo_status)
        app.router.add_post("/api/go-nogo/poll", self._handle_go_nogo_poll)
        app.router.add_post("/api/go-nogo/respond", self._handle_go_nogo_respond)
        # Shift handover
        app.router.add_get("/api/handover", self._handle_handover_get)
        app.router.add_post("/api/handover", self._handle_handover_post)
        # Alarm journal (Feature 2)
        app.router.add_get("/api/alarms", self._handle_alarms_get)
        app.router.add_post("/api/alarms/{alarm_id}/ack", self._handle_alarm_ack)
        # Client config endpoint (planner URL for distributed deployments)
        app.router.add_get("/api/client-config", self._handle_client_config)
        # Contact window timeline proxy (Feature 1)
        app.router.add_get("/api/contacts", self._handle_contacts_proxy)
        # Stored TM playback (Feature 3)
        app.router.add_post("/api/tm-dump", self._handle_tm_dump)
        app.router.add_get("/api/tm-dump-data", self._handle_tm_dump_data)
        # TM archive query endpoints (persistent SQLite)
        app.router.add_get("/api/archive/parameters", self._handle_archive_params)
        app.router.add_get("/api/archive/events", self._handle_archive_events)
        app.router.add_get("/api/archive/alarms", self._handle_archive_alarms)
        app.router.add_get("/api/archive/playback", self._handle_archive_playback)
        static_dir = Path(__file__).parent / "static"
        if static_dir.exists():
            app.router.add_static("/static/", static_dir)

        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, "0.0.0.0", self.http_port)
        await site.start()
        logger.info("MCS server started on port %d", self.http_port)

        # Start state polling, TM receive, and TC connection in parallel
        await asyncio.gather(
            self._tm_receive_loop(),
            self._state_poll_loop(),
            self._tc_connect_loop(),
        )

    async def _tc_connect_loop(self):
        """Maintain persistent TCP connection to simulator TC port."""
        while self._running:
            try:
                _, writer = await asyncio.open_connection(
                    self.connect_host, self.tc_port)
                self._tc_writer = writer
                logger.info("Connected to TC port at %s:%d",
                            self.connect_host, self.tc_port)
                while self._running:
                    if writer.is_closing():
                        break
                    await asyncio.sleep(2)
            except Exception as e:
                logger.warning("TC connection error: %s, reconnecting...", e)
                self._tc_writer = None
                await asyncio.sleep(3)

    async def _tm_receive_loop(self):
        while self._running:
            try:
                reader, writer = await asyncio.open_connection(
                    self.connect_host, self.connect_port)
                logger.info("Connected to TM source at %s:%d",
                            self.connect_host, self.connect_port)
                while self._running:
                    pkt = await read_framed_packet(reader)
                    if pkt is None:
                        break
                    parsed = decommutate_packet(pkt)
                    if parsed and parsed.secondary:
                        await self._process_tm(parsed)
            except Exception as e:
                logger.warning("TM connection error: %s, reconnecting...", e)
                await asyncio.sleep(2)

    async def _process_tm(self, pkt) -> None:
        info = {
            "service": pkt.secondary.service,
            "subtype": pkt.secondary.subtype,
            "apid": pkt.primary.apid,
            "seq": pkt.primary.sequence_count,
            "data_len": len(pkt.data_field),
        }

        # Parse S1 verification TM
        if pkt.secondary.service == 1 and len(pkt.data_field) >= 4:
            request_id = struct.unpack('>I', pkt.data_field[:4])[0]
            tc_seq = request_id & 0x3FFF
            error_code = 0
            if pkt.secondary.subtype in (2, 8) and len(pkt.data_field) >= 6:
                error_code = struct.unpack('>H', pkt.data_field[4:6])[0]

            verif = {
                "tc_seq": tc_seq,
                "subtype": pkt.secondary.subtype,
                "error_code": error_code,
            }
            info["verification"] = verif

            for entry in self._verification_log:
                if entry.get("seq") == tc_seq:
                    if pkt.secondary.subtype == 1:
                        entry["state"] = "ACCEPTED"
                    elif pkt.secondary.subtype == 2:
                        entry["state"] = "REJECTED"
                        entry["error_code"] = error_code
                    elif pkt.secondary.subtype == 7:
                        entry["state"] = "COMPLETED"
                    elif pkt.secondary.subtype == 8:
                        entry["state"] = "FAILED"
                        entry["error_code"] = error_code
                    break

        # Parse S3 housekeeping TM
        if pkt.secondary.service == 3 and len(pkt.data_field) >= 2:
            sid = struct.unpack('>H', pkt.data_field[:2])[0]
            info["hk_info"] = f"SID={sid} ({len(pkt.data_field) - 2}B payload)"

        # Parse S20 parameter value reports
        if pkt.secondary.service == 20 and len(pkt.data_field) >= 3:
            param_id = struct.unpack('>H', pkt.data_field[:2])[0]
            info["param_info"] = f"Param 0x{param_id:04X}"

        # Parse S5 events
        if pkt.secondary.service == 5 and len(pkt.data_field) >= 3:
            event_id = struct.unpack('>H', pkt.data_field[:2])[0]
            severity = pkt.data_field[2]
            aux_text = ""
            if len(pkt.data_field) >= 7:
                cuc_time = struct.unpack('>I', pkt.data_field[3:7])[0]
                if len(pkt.data_field) > 7:
                    text_len = pkt.data_field[7]
                    if len(pkt.data_field) >= 8 + text_len:
                        aux_text = pkt.data_field[8:8+text_len].decode(
                            'ascii', errors='ignore'
                        )
            info["event"] = {
                "event_id": event_id,
                "severity": severity,
                "description": aux_text,
            }

        # Parse S12 monitoring transition reports
        if pkt.secondary.service == 12 and pkt.secondary.subtype in (9, 10):
            if len(pkt.data_field) >= 6:
                param_id = struct.unpack('>H', pkt.data_field[:2])[0]
                value = struct.unpack('>f', pkt.data_field[2:6])[0]
                info["monitoring"] = {
                    "param_id": param_id,
                    "value": value,
                    "transition": "out_of_limits" if pkt.secondary.subtype == 9 else "back_to_nominal",
                }

        # -- Alarm journal: capture S5 events (severity >= 3) and S12 OOL --
        if pkt.secondary.service == 5 and info.get("event"):
            evt = info["event"]
            # Archive every S5 event
            try:
                self._archive.store_event(
                    evt["event_id"], evt.get("severity", 0),
                    self._event_id_to_subsystem(evt["event_id"]),
                    evt.get("description", ""),
                )
            except Exception:
                pass

            if evt.get("severity", 0) >= 3:
                self._alarm_id_counter += 1
                alarm = {
                    "id": self._alarm_id_counter,
                    "timestamp": _time_mod.time(),
                    "severity": evt["severity"],
                    "subsystem": self._event_id_to_subsystem(evt["event_id"]),
                    "parameter": f"EVT-{evt['event_id']}",
                    "value": evt.get("description", ""),
                    "limit": "",
                    "acknowledged": False,
                    "source": "S5",
                }
                self._alarm_journal.appendleft(alarm)
                try:
                    self._archive.store_alarm(alarm)
                except Exception:
                    pass
                # Broadcast alarm to all WS clients
                alarm_msg = json.dumps({"type": "alarm", "alarm": alarm})
                for ws, _pos in self._ws_clients:
                    try:
                        await ws.send_str(alarm_msg)
                    except Exception:
                        pass

        if pkt.secondary.service == 12 and pkt.secondary.subtype == 9:
            mon = info.get("monitoring")
            if mon:
                self._alarm_id_counter += 1
                alarm = {
                    "id": self._alarm_id_counter,
                    "timestamp": _time_mod.time(),
                    "severity": 3,
                    "subsystem": self._param_id_to_subsystem(mon["param_id"]),
                    "parameter": f"0x{mon['param_id']:04X}",
                    "value": str(round(mon["value"], 4)),
                    "limit": "OOL",
                    "acknowledged": False,
                    "source": "S12",
                }
                self._alarm_journal.appendleft(alarm)
                try:
                    self._archive.store_alarm(alarm)
                except Exception:
                    pass
                alarm_msg = json.dumps({"type": "alarm", "alarm": alarm})
                for ws, _pos in self._ws_clients:
                    try:
                        await ws.send_str(alarm_msg)
                    except Exception:
                        pass

        # Broadcast to WebSocket clients
        msg = json.dumps({"type": "tm", "packet": info})
        disconnected = []
        for ws, _pos in self._ws_clients:
            try:
                await ws.send_str(msg)
            except Exception:
                disconnected.append((ws, _pos))
        for item in disconnected:
            self._ws_clients.remove(item)

    async def _state_poll_loop(self):
        """Periodically fetch gated simulator state and broadcast."""
        async with aiohttp.ClientSession() as session:
            while self._running:
                try:
                    async with session.get(
                        self.sim_api_url,
                        timeout=aiohttp.ClientTimeout(total=2),
                    ) as resp:
                        if resp.status == 200:
                            data = await resp.json()
                            if data.get("stale"):
                                self._latest_state["stale"] = True
                                for key in (
                                    "in_contact", "downlink_active",
                                    "uplink_active", "override_passes",
                                    "sim_time", "speed", "tick",
                                ):
                                    if key in data:
                                        self._latest_state[key] = data[key]
                            else:
                                self._latest_state = data
                            msg = json.dumps({
                                "type": "state",
                                "data": self._latest_state,
                            })
                            disconnected = []
                            for ws, _pos in self._ws_clients:
                                try:
                                    await ws.send_str(msg)
                                except Exception:
                                    disconnected.append((ws, _pos))
                            for item in disconnected:
                                self._ws_clients.remove(item)

                            # Archive parameters every 10 polls (~10 s)
                            self._archive_tick += 1
                            if self._archive_tick % 10 == 0:
                                self._archive_state_snapshot(data)
                except Exception:
                    pass
                await asyncio.sleep(1.0)

    async def _handle_sim_state(self, request):
        return web.json_response(self._latest_state)

    def _archive_state_snapshot(self, data: dict) -> None:
        """Extract key parameters from a state poll and store them."""
        params: dict[str, float] = {}
        for subsys in ("eps", "aocs", "tcs", "ttc", "payload", "obdh"):
            sub = data.get(subsys)
            if not isinstance(sub, dict):
                continue
            for key, val in sub.items():
                if isinstance(val, (int, float)):
                    params[f"{subsys}.{key}"] = float(val)
        if params:
            try:
                self._archive.store_parameters(params)
            except Exception as e:
                logger.debug("Archive store error: %s", e)

    # ── TM archive query endpoints ────────────────────────────────

    async def _handle_archive_params(self, request):
        """GET /api/archive/parameters?name=eps.bat_soc&start=<epoch>&end=<epoch>&limit=3600"""
        name = request.query.get("name", "")
        if not name:
            return web.json_response({"error": "name parameter required"}, status=400)
        start = float(request.query["start"]) if "start" in request.query else None
        end = float(request.query["end"]) if "end" in request.query else None
        limit = int(request.query.get("limit", 3600))
        data = self._archive.query_parameters(name, start, end, limit)
        return web.json_response({"param_name": name, "data": data})

    async def _handle_archive_events(self, request):
        """GET /api/archive/events?start=<epoch>&end=<epoch>&severity=0&limit=500"""
        start = float(request.query["start"]) if "start" in request.query else None
        end = float(request.query["end"]) if "end" in request.query else None
        sev = int(request.query.get("severity", 0))
        limit = int(request.query.get("limit", 500))
        data = self._archive.query_events(start, end, sev, limit)
        return web.json_response({"events": data})

    async def _handle_archive_alarms(self, request):
        """GET /api/archive/alarms?start=<epoch>&end=<epoch>&limit=500"""
        start = float(request.query["start"]) if "start" in request.query else None
        end = float(request.query["end"]) if "end" in request.query else None
        limit = int(request.query.get("limit", 500))
        data = self._archive.query_alarms(start, end, limit)
        return web.json_response({"alarms": data})

    async def _handle_archive_playback(self, request):
        """GET /api/archive/playback?subsystem=eps&start=<epoch>&end=<epoch>"""
        subsystem = request.query.get("subsystem", "")
        if not subsystem:
            return web.json_response({"error": "subsystem parameter required"}, status=400)
        start = float(request.query["start"]) if "start" in request.query else None
        end = float(request.query["end"]) if "end" in request.query else None
        data = self._archive.get_playback_data(subsystem, start, end)
        return web.json_response({"subsystem": subsystem, "data": data})

    async def _handle_command(self, request):
        """Proxy telecommands to the simulator's HTTP API (backward compat)."""
        try:
            cmd = await request.json()
            async with aiohttp.ClientSession() as session:
                url = f"{self.sim_api_base}/api/command"
                async with session.post(
                    url, json=cmd,
                    timeout=aiohttp.ClientTimeout(total=5),
                ) as resp:
                    result = await resp.json()
                    return web.json_response(result, status=resp.status)
        except Exception as e:
            return web.json_response(
                {"status": "error", "message": str(e)}, status=502
            )

    async def _handle_pus_command(self, request):
        """Build and send a real ECSS PUS TC packet to the simulator."""
        try:
            body = await request.json()
            service = int(body.get("service", 0))
            subtype = int(body.get("subtype", 0))
            data_hex = body.get("data_hex", "")
            name = body.get("name", f"S{service}.{subtype}")
            position = body.get("position", "flight_director")

            # Position-based access control
            allowed, reason = self._check_position_access(
                position, service, subtype, data_hex
            )
            if not allowed:
                return web.json_response(
                    {"status": "denied", "message": reason}, status=403
                )

            data = bytes.fromhex(data_hex) if data_hex else b''
            pkt = self._tc_manager.build_command(service, subtype, data)
            seq = self._tc_manager._seq_count

            # Track in verification log
            import time
            entry = {
                "seq": seq,
                "name": name,
                "service": service,
                "subtype": subtype,
                "state": "SENT",
                "timestamp": time.time(),
                "error_code": 0,
                "position": position,
            }
            self._verification_log.appendleft(entry)
            self._tc_manager.track_verification(seq, name)

            # Send over TC TCP connection
            if self._tc_writer is None or self._tc_writer.is_closing():
                return web.json_response(
                    {"status": "error", "message": "No TC connection"},
                    status=503,
                )

            framed = frame_packet(pkt)
            self._tc_writer.write(framed)
            await self._tc_writer.drain()

            return web.json_response({"status": "sent", "seq": seq})
        except Exception as e:
            logger.warning("PUS command error: %s", e)
            return web.json_response(
                {"status": "error", "message": str(e)}, status=400
            )

    async def _handle_verification_log(self, request):
        return web.json_response({"log": list(self._verification_log)})

    async def _handle_index(self, request):
        index_file = Path(__file__).parent / "static" / "index.html"
        if index_file.exists():
            return web.FileResponse(index_file)
        return web.Response(
            text="<h1>SMO MCS — static/index.html not found</h1>",
            content_type="text/html",
        )

    async def _handle_ws(self, request):
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        # Position from query param: /ws?position=eps_tcs
        position = request.query.get("position", "flight_director")
        self._ws_clients.append((ws, position))
        try:
            async for msg in ws:
                # Handle incoming WS messages (e.g., position change)
                if msg.type == aiohttp.WSMsgType.TEXT:
                    try:
                        data = json.loads(msg.data)
                        if data.get("type") == "set_position":
                            new_pos = data.get("position", "flight_director")
                            for i, (w, p) in enumerate(self._ws_clients):
                                if w is ws:
                                    self._ws_clients[i] = (ws, new_pos)
                                    break
                        elif data.get("type") == "go_nogo_response":
                            # Handle inline GO/NO-GO response via WS
                            go_pos = data.get("position", position)
                            go_resp = data.get("response", "").upper()
                            if (self._go_nogo_active
                                    and go_resp in ("GO", "NOGO", "STANDBY")):
                                self._go_nogo_responses[go_pos] = go_resp
                                status_msg = json.dumps({
                                    "type": "go_nogo_status",
                                    "active": True,
                                    "label": self._go_nogo_label,
                                    "responses": self._go_nogo_responses,
                                })
                                for w, _p in self._ws_clients:
                                    try:
                                        await w.send_str(status_msg)
                                    except Exception:
                                        pass
                    except (json.JSONDecodeError, KeyError):
                        pass
        finally:
            self._ws_clients = [
                (w, p) for w, p in self._ws_clients if w is not ws
            ]
        return ws

    async def _handle_displays(self, request):
        return web.json_response(
            self._displays.model_dump()
            if hasattr(self._displays, 'model_dump')
            else {}
        )

    async def _handle_state(self, request):
        return web.json_response(self._latest_state)

    async def _handle_positions(self, request):
        """Return available positions and their access control config."""
        result = {}
        for name, pos in self._positions.items():
            result[name] = {
                "label": pos.label or pos.display_name,
                "display_name": pos.display_name,
                "subsystems": pos.subsystems,
                "allowed_commands": pos.allowed_commands,
                "allowed_services": pos.allowed_services,
                "allowed_func_ids": pos.allowed_func_ids,
                "visible_tabs": pos.visible_tabs,
                "overview_subsystems": pos.overview_subsystems,
                "manual_sections": pos.manual_sections,
            }
        return web.json_response({"positions": result})

    async def _handle_tc_catalog(self, request):
        """Return TC catalog with command metadata."""
        position = request.query.get("position", "flight_director")
        commands = []
        for cmd in self._tc_catalog:
            cmd_dict = cmd.model_dump() if hasattr(cmd, 'model_dump') else {}
            # Filter by position access
            service = cmd_dict.get("service", 0)
            subtype = cmd_dict.get("subtype", 0)
            func_id = cmd_dict.get("func_id")
            data_hex = f"{func_id:02X}" if func_id is not None else ""
            allowed, _ = self._check_position_access(
                position, service, subtype, data_hex
            )
            cmd_dict["allowed"] = allowed
            commands.append(cmd_dict)
        return web.json_response({"commands": commands})

    # ── Procedure runner helpers ────────────────────────────────────

    async def _proc_send_command(
        self, service: int, subtype: int, data_hex: str = ""
    ) -> dict:
        """Send a PUS command on behalf of the procedure runner."""
        import time as _time
        data = bytes.fromhex(data_hex) if data_hex else b""
        pkt = self._tc_manager.build_command(service, subtype, data)
        seq = self._tc_manager._seq_count

        entry = {
            "seq": seq,
            "name": f"PROC:S{service}.{subtype}",
            "service": service,
            "subtype": subtype,
            "state": "SENT",
            "timestamp": _time.time(),
            "error_code": 0,
            "position": "procedure_runner",
        }
        self._verification_log.appendleft(entry)
        self._tc_manager.track_verification(seq, entry["name"])

        if self._tc_writer is None or self._tc_writer.is_closing():
            return {"status": "error", "message": "No TC connection"}

        framed = frame_packet(pkt)
        self._tc_writer.write(framed)
        await self._tc_writer.drain()
        return {"status": "sent", "seq": seq}

    def _proc_get_telemetry(self, param_path: str) -> Any:
        """Read a telemetry value by dot-path from the latest state."""
        state = self._latest_state
        if not state:
            return None
        # Try direct subsystem.param lookup in latest state dict
        parts = param_path.split(".", 1)
        if len(parts) == 2:
            subsystem, param = parts
            sub_data = state.get(subsystem, {})
            if isinstance(sub_data, dict):
                return sub_data.get(param)
        return state.get(param_path)

    # ── Procedure API handlers ───────────────────────────────────────

    async def _handle_proc_load(self, request):
        """Load a procedure by activity type name or direct command sequence."""
        try:
            body = await request.json()
            name = body.get("name", "")
            steps = body.get("steps")
            procedure_ref = body.get("procedure_ref", "")
            step_by_step = body.get("step_by_step", False)

            # If steps not provided, look up by activity type name
            if steps is None:
                for at in self._activity_types:
                    if at["name"] == name:
                        steps = at.get("command_sequence", [])
                        procedure_ref = procedure_ref or at.get("procedure_ref", "")
                        break
                if steps is None:
                    return web.json_response(
                        {"error": f"Activity type '{name}' not found"}, status=404
                    )

            result = self._procedure_runner.load(
                name, steps, procedure_ref=procedure_ref,
                step_by_step=step_by_step,
            )
            return web.json_response(result)
        except Exception as e:
            return web.json_response({"error": str(e)}, status=400)

    async def _handle_proc_start(self, request):
        result = await self._procedure_runner.start()
        return web.json_response(result)

    async def _handle_proc_pause(self, request):
        result = await self._procedure_runner.pause()
        return web.json_response(result)

    async def _handle_proc_resume(self, request):
        result = await self._procedure_runner.resume()
        return web.json_response(result)

    async def _handle_proc_abort(self, request):
        result = await self._procedure_runner.abort()
        return web.json_response(result)

    async def _handle_proc_step(self, request):
        result = await self._procedure_runner.step_advance()
        return web.json_response(result)

    async def _handle_proc_skip(self, request):
        result = await self._procedure_runner.skip_step()
        return web.json_response(result)

    async def _handle_proc_status(self, request):
        return web.json_response(self._procedure_runner.status())

    async def _handle_proc_override(self, request):
        try:
            body = await request.json()
            service = int(body.get("service", 0))
            subtype = int(body.get("subtype", 0))
            data_hex = body.get("data_hex", "")
            result = await self._procedure_runner.override_command(
                service, subtype, data_hex
            )
            return web.json_response(result)
        except Exception as e:
            return web.json_response({"error": str(e)}, status=400)

    async def _handle_activity_types(self, request):
        return web.json_response({"activity_types": self._activity_types})

    async def _handle_proc_index(self, request):
        return web.json_response({"procedures": self._procedure_index})

    # ── Shift handover ───────────────────────────────────────────────

    async def _handle_handover_get(self, request):
        return web.json_response({"notes": self._handover_log})

    async def _handle_handover_post(self, request):
        import time as _time
        try:
            body = await request.json()
            note = body.get("note", "").strip()
            position = body.get("position", "unknown")
            if not note:
                return web.json_response(
                    {"error": "Note text required"}, status=400)
            entry = {
                "timestamp": _time.time(),
                "position": position,
                "note": note,
            }
            self._handover_log.append(entry)
            return web.json_response({"status": "ok", "entry": entry})
        except Exception as e:
            return web.json_response({"error": str(e)}, status=400)

    def _scan_docs(self, base_dir: Path) -> list[dict]:
        """Scan a directory tree for markdown files."""
        entries = []
        if not base_dir.exists():
            return entries
        for md_file in sorted(base_dir.rglob("*.md")):
            rel = md_file.relative_to(base_dir)
            category = rel.parent.name if rel.parent != rel.parent.parent else "general"
            entries.append({
                "category": category or "general",
                "name": md_file.stem.replace("_", " ").title(),
                "path": str(rel),
                "filename": md_file.name,
            })
        return entries

    async def _handle_procedures_list(self, request):
        proc_dir = self.config_dir / "procedures"
        entries = self._scan_docs(proc_dir)
        return web.json_response({"procedures": entries})

    async def _handle_procedure_file(self, request):
        rel_path = request.match_info["path"]
        proc_dir = self.config_dir / "procedures"
        target = (proc_dir / rel_path).resolve()
        if not str(target).startswith(str(proc_dir.resolve())):
            return web.json_response({"error": "Invalid path"}, status=403)
        if not target.exists() or not target.is_file():
            return web.json_response({"error": "Not found"}, status=404)
        content = target.read_text(encoding="utf-8")
        title = (
            content.split("\n", 1)[0].lstrip("# ").strip()
            if content
            else rel_path
        )
        return web.json_response({"title": title, "content_md": content})

    async def _handle_manual_list(self, request):
        manual_dir = self.config_dir / "manual"
        entries = self._scan_docs(manual_dir)
        return web.json_response({"pages": entries})

    async def _handle_manual_file(self, request):
        rel_path = request.match_info["path"]
        manual_dir = self.config_dir / "manual"
        target = (manual_dir / rel_path).resolve()
        if not str(target).startswith(str(manual_dir.resolve())):
            return web.json_response({"error": "Invalid path"}, status=403)
        if not target.exists() or not target.is_file():
            return web.json_response({"error": "Not found"}, status=404)
        content = target.read_text(encoding="utf-8")
        title = (
            content.split("\n", 1)[0].lstrip("# ").strip()
            if content
            else rel_path
        )
        return web.json_response({"title": title, "content_md": content})

    # ── Procedure builder save/load ──────────────────────────────────

    async def _handle_proc_save(self, request):
        """Save a custom procedure built in the procedure builder."""
        import yaml
        try:
            body = await request.json()
            name = body.get("name", "").strip()
            steps = body.get("steps", [])
            description = body.get("description", "")
            position = body.get("position", "unknown")
            if not name:
                return web.json_response(
                    {"error": "Procedure name required"}, status=400)

            custom_dir = self.config_dir / "procedures" / "custom"
            custom_dir.mkdir(parents=True, exist_ok=True)

            # Sanitize filename
            safe_name = "".join(
                c if c.isalnum() or c in "-_" else "_"
                for c in name.lower().replace(" ", "_")
            )
            filepath = custom_dir / f"{safe_name}.yaml"

            proc_data = {
                "name": name,
                "description": description,
                "created_by": position,
                "steps": steps,
            }
            with open(filepath, "w") as f:
                yaml.dump(proc_data, f, default_flow_style=False)

            return web.json_response({
                "status": "saved",
                "path": f"custom/{safe_name}.yaml",
            })
        except Exception as e:
            return web.json_response({"error": str(e)}, status=400)

    async def _handle_proc_custom_list(self, request):
        """List custom procedures."""
        custom_dir = self.config_dir / "procedures" / "custom"
        entries = []
        if custom_dir.exists():
            import yaml
            for f in sorted(custom_dir.glob("*.yaml")):
                try:
                    with open(f) as fh:
                        data = yaml.safe_load(fh)
                    entries.append({
                        "name": data.get("name", f.stem),
                        "description": data.get("description", ""),
                        "path": f"custom/{f.name}",
                        "steps": data.get("steps", []),
                        "created_by": data.get("created_by", "unknown"),
                    })
                except Exception:
                    pass
        return web.json_response({"procedures": entries})

    # ── Alarm journal helpers ────────────────────────────────────────

    @staticmethod
    def _event_id_to_subsystem(event_id: int) -> str:
        """Map event ID range to subsystem name."""
        if 0x0100 <= event_id <= 0x01FF:
            return "eps"
        elif 0x0200 <= event_id <= 0x02FF:
            return "aocs"
        elif 0x0300 <= event_id <= 0x03FF:
            return "obdh"
        elif 0x0400 <= event_id <= 0x04FF:
            return "tcs"
        elif 0x0500 <= event_id <= 0x05FF:
            return "ttc"
        elif 0x0600 <= event_id <= 0x06FF:
            return "payload"
        return "unknown"

    @staticmethod
    def _param_id_to_subsystem(param_id: int) -> str:
        """Map parameter ID range to subsystem name."""
        if 0x0100 <= param_id <= 0x01FF:
            return "eps"
        elif 0x0200 <= param_id <= 0x02FF:
            return "aocs"
        elif 0x0300 <= param_id <= 0x03FF:
            return "obdh"
        elif 0x0400 <= param_id <= 0x04FF:
            return "tcs"
        elif 0x0500 <= param_id <= 0x05FF:
            return "ttc"
        elif 0x0600 <= param_id <= 0x06FF:
            return "payload"
        return "unknown"

    # ── Alarm journal API handlers ────────────────────────────────────

    async def _handle_alarms_get(self, request):
        """Return alarm journal entries, optionally filtered."""
        subsystem = request.query.get("subsystem")
        severity = request.query.get("severity")
        alarms = list(self._alarm_journal)
        if subsystem:
            alarms = [a for a in alarms if a["subsystem"] == subsystem]
        if severity:
            try:
                sev_min = int(severity)
                alarms = [a for a in alarms if a["severity"] >= sev_min]
            except ValueError:
                pass
        return web.json_response({"alarms": alarms})

    async def _handle_alarm_ack(self, request):
        """Acknowledge an alarm by ID."""
        try:
            alarm_id = int(request.match_info["alarm_id"])
            for alarm in self._alarm_journal:
                if alarm["id"] == alarm_id:
                    alarm["acknowledged"] = True
                    return web.json_response({
                        "status": "acknowledged", "id": alarm_id
                    })
            return web.json_response(
                {"error": f"Alarm {alarm_id} not found"}, status=404
            )
        except (ValueError, KeyError) as e:
            return web.json_response({"error": str(e)}, status=400)

    # ── Client config (distributed deployment) ──────────────────────

    async def _handle_client_config(self, request):
        """Return runtime config for the browser client."""
        return web.json_response({
            "planner_url": self._planner_api_base,
        })

    # ── Contact window timeline proxy (Feature 1) ────────────────────

    async def _handle_contacts_proxy(self, request):
        """Proxy contact window data from the planner API."""
        try:
            async with aiohttp.ClientSession() as session:
                url = f"{self._planner_api_base}/api/contacts"
                async with session.get(
                    url, timeout=aiohttp.ClientTimeout(total=5)
                ) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        return web.json_response(data)
                    return web.json_response(
                        {"contacts": [], "error": f"Planner returned {resp.status}"},
                        status=resp.status,
                    )
        except Exception as e:
            # Planner not available — return synthetic data from state
            contacts = self._build_synthetic_contacts()
            return web.json_response({"contacts": contacts, "synthetic": True})

    def _build_synthetic_contacts(self) -> list[dict]:
        """Build synthetic contact windows from current state for when
        the planner is not available."""
        contacts = []
        now = _time_mod.time()
        gs_list = [
            {"name": "Iqaluit", "color": "#3b82f6"},
            {"name": "Troll", "color": "#22c55e"},
        ]
        # Generate 6 synthetic passes over 24h
        for i, gs in enumerate(gs_list):
            for j in range(3):
                aos = now + (j * 4 + i * 2) * 3600 + 1800
                los = aos + 600 + j * 120
                contacts.append({
                    "ground_station": gs["name"],
                    "color": gs["color"],
                    "aos_utc": aos,
                    "los_utc": los,
                    "max_elevation_deg": 25 + j * 15 + i * 10,
                    "duration_s": los - aos,
                })
        contacts.sort(key=lambda c: c["aos_utc"])
        return contacts

    # ── Stored TM dump (Feature 3) ────────────────────────────────────

    async def _handle_tm_dump(self, request):
        """Send S15.9 dump command and return acknowledgment."""
        try:
            body = await request.json()
            store_id = int(body.get("store_id", 1))
            subsystem = body.get("subsystem", "unknown")

            # Send S15.9 (start dump) command
            data = bytes([store_id])
            pkt = self._tc_manager.build_command(15, 9, data)
            seq = self._tc_manager._seq_count

            entry = {
                "seq": seq,
                "name": f"TM_DUMP_S15.9_store{store_id}",
                "service": 15,
                "subtype": 9,
                "state": "SENT",
                "timestamp": _time_mod.time(),
                "error_code": 0,
                "position": "tm_dump",
            }
            self._verification_log.appendleft(entry)

            if self._tc_writer is None or self._tc_writer.is_closing():
                return web.json_response(
                    {"status": "error", "message": "No TC connection"},
                    status=503,
                )

            from smo_common.protocol.framing import frame_packet
            framed = frame_packet(pkt)
            self._tc_writer.write(framed)
            await self._tc_writer.drain()

            # Try to use real archived data; fall back to synthetic
            dump_key = f"{subsystem}_{store_id}"
            archived = self._archive.get_playback_data(subsystem)
            if archived:
                self._tm_dump_data[dump_key] = archived
            else:
                self._tm_dump_data[dump_key] = self._generate_dump_data(
                    subsystem, store_id
                )

            return web.json_response({
                "status": "sent",
                "seq": seq,
                "dump_key": dump_key,
            })
        except Exception as e:
            logger.warning("TM dump error: %s", e)
            return web.json_response(
                {"status": "error", "message": str(e)}, status=400
            )

    async def _handle_tm_dump_data(self, request):
        """Return stored TM dump data for playback."""
        dump_key = request.query.get("key", "")
        data = self._tm_dump_data.get(dump_key, [])
        return web.json_response({"dump_key": dump_key, "data": data})

    def _generate_dump_data(self, subsystem: str, store_id: int) -> list[dict]:
        """Generate synthetic historical TM data for dump playback."""
        import math
        import random
        now = _time_mod.time()
        points = []
        # Generate 60 data points going back 1 hour
        for i in range(60):
            t = now - (60 - i) * 60  # 1-minute intervals
            point = {"timestamp": t, "index": i}
            if subsystem == "eps":
                point["soc_pct"] = max(20, min(100,
                    70 + 15 * math.sin(i * 0.1) + random.gauss(0, 1)))
                point["power_gen_W"] = max(0,
                    30 + 25 * max(0, math.sin(i * 0.08)) + random.gauss(0, 2))
                point["power_cons_W"] = 22 + random.gauss(0, 1.5)
            elif subsystem == "aocs":
                point["rate_roll"] = random.gauss(0, 0.02)
                point["rate_pitch"] = random.gauss(0, 0.02)
                point["rate_yaw"] = random.gauss(0, 0.02)
                point["att_error_deg"] = abs(random.gauss(0.1, 0.05))
            elif subsystem == "tcs":
                point["temp_obc_C"] = 25 + 5 * math.sin(i * 0.05) + random.gauss(0, 0.5)
                point["temp_battery_C"] = 20 + 3 * math.sin(i * 0.05) + random.gauss(0, 0.3)
                point["temp_fpa_C"] = -15 + 2 * math.sin(i * 0.05) + random.gauss(0, 0.2)
            elif subsystem == "ttc":
                in_contact = math.sin(i * 0.15) > 0.3
                point["rssi_dbm"] = -85 + (20 if in_contact else 0) + random.gauss(0, 2)
            elif subsystem == "obdh":
                point["cpu_load"] = 15 + 5 * math.sin(i * 0.1) + random.gauss(0, 2)
            elif subsystem == "payload":
                point["fpa_temp"] = -15 + 2 * math.sin(i * 0.05) + random.gauss(0, 0.3)
            points.append(point)
        return points

    # ── GO/NO-GO coordination ────────────────────────────────────────

    async def _handle_go_nogo_status(self, request):
        """Return current GO/NO-GO poll state."""
        return web.json_response({
            "active": self._go_nogo_active,
            "label": self._go_nogo_label,
            "initiator": self._go_nogo_initiator,
            "responses": self._go_nogo_responses,
        })

    async def _handle_go_nogo_poll(self, request):
        """Initiate a GO/NO-GO poll (Flight Director only)."""
        try:
            body = await request.json()
            position = body.get("position", "")
            label = body.get("label", "GO/NO-GO Poll")

            if position != "flight_director":
                return web.json_response(
                    {"error": "Only Flight Director can initiate polls"},
                    status=403,
                )

            self._go_nogo_active = True
            self._go_nogo_label = label
            self._go_nogo_initiator = position
            self._go_nogo_responses = {
                "flight_director": "GO",
            }

            # Broadcast poll to all WebSocket clients
            msg = json.dumps({
                "type": "go_nogo_poll",
                "label": label,
                "initiator": position,
            })
            disconnected = []
            for ws, _pos in self._ws_clients:
                try:
                    await ws.send_str(msg)
                except Exception:
                    disconnected.append((ws, _pos))
            for item in disconnected:
                self._ws_clients.remove(item)

            return web.json_response({"status": "poll_started", "label": label})
        except Exception as e:
            return web.json_response({"error": str(e)}, status=400)

    async def _handle_go_nogo_respond(self, request):
        """Submit a GO/NO-GO response for a position."""
        try:
            body = await request.json()
            position = body.get("position", "")
            response = body.get("response", "").upper()

            if not self._go_nogo_active:
                return web.json_response(
                    {"error": "No active poll"}, status=400)

            if response not in ("GO", "NOGO", "STANDBY"):
                return web.json_response(
                    {"error": "Response must be GO, NOGO, or STANDBY"},
                    status=400,
                )

            self._go_nogo_responses[position] = response

            # Broadcast updated status to all clients
            msg = json.dumps({
                "type": "go_nogo_status",
                "active": True,
                "label": self._go_nogo_label,
                "responses": self._go_nogo_responses,
            })
            disconnected = []
            for ws, _pos in self._ws_clients:
                try:
                    await ws.send_str(msg)
                except Exception:
                    disconnected.append((ws, _pos))
            for item in disconnected:
                self._ws_clients.remove(item)

            # Check if all positions have responded
            positions_with_access = set(self._positions.keys())
            responded = set(self._go_nogo_responses.keys())
            if positions_with_access <= responded:
                all_go = all(
                    v == "GO" for v in self._go_nogo_responses.values()
                )
                result = "ALL_GO" if all_go else "NO_GO"
                self._go_nogo_active = False

                result_msg = json.dumps({
                    "type": "go_nogo_result",
                    "result": result,
                    "label": self._go_nogo_label,
                    "responses": self._go_nogo_responses,
                })
                for ws, _pos in self._ws_clients:
                    try:
                        await ws.send_str(result_msg)
                    except Exception:
                        pass

            return web.json_response({
                "status": "recorded",
                "position": position,
                "response": response,
                "all_responses": self._go_nogo_responses,
            })
        except Exception as e:
            return web.json_response({"error": str(e)}, status=400)


def main():
    parser = argparse.ArgumentParser(description="SMO Mission Control System")
    parser.add_argument("--connect", default="localhost:8002",
                        help="TM source host:port")
    parser.add_argument("--config", default="configs/eosat1/",
                        help="Config directory")
    parser.add_argument("--port", type=int, default=9090, help="HTTP port")
    args = parser.parse_args()

    host, port = args.connect.rsplit(":", 1)
    logging.basicConfig(level=logging.INFO)
    server = MCSServer(args.config, host, int(port), args.port)
    asyncio.run(server.start())


if __name__ == "__main__":
    main()
