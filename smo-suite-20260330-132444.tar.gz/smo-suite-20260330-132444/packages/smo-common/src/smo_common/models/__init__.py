"""SMO Common — Model interfaces."""
