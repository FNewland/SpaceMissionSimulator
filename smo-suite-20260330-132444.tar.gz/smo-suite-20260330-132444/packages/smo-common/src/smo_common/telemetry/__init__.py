"""SMO Common — Telemetry utilities."""
