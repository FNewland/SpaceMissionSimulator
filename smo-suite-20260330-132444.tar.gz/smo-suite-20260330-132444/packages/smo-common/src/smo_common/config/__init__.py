"""SMO Common — Configuration management."""
