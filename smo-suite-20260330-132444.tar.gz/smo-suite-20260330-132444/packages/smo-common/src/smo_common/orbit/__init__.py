"""SMO Common — Orbit utilities."""
