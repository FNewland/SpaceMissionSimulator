"""SMO Simulator — Simulation Engine.

Config-driven central tick loop. Loads subsystem models from the registry,
manages shared parameter store, PUS packet queues, and FDIR callbacks.
"""
import threading
import time
import queue
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Optional

from smo_common.config.loader import (
    load_mission_config, load_orbit_config, load_all_subsystem_configs,
    load_fdir_config, load_hk_structures,
)
from smo_common.orbit.propagator import OrbitPropagator, GroundStation
from smo_common.models.registry import create_model
from smo_common.telemetry.tm_builder import TMBuilder
from smo_simulator.tc_scheduler import TCScheduler
from smo_simulator.tm_storage import OnboardTMStorage

logger = logging.getLogger(__name__)


class SimulationEngine:
    """Config-driven simulation engine.

    Reads mission config, instantiates subsystem models from registry,
    runs tick loop, manages shared parameter store and packet queues.
    """

    def __init__(self, config_dir: str | Path, speed: float = 1.0):
        self.config_dir = Path(config_dir)
        self.speed = speed
        self.running = False
        self._tick_count = 0

        # Shared parameter store
        self.params: dict[int, float] = {}

        # Thread-safe queues
        self.tm_queue: queue.Queue = queue.Queue(maxsize=2000)
        self.tc_queue: queue.Queue = queue.Queue(maxsize=500)
        self.instr_queue: queue.Queue = queue.Queue(maxsize=200)
        self.event_queue: queue.Queue = queue.Queue(maxsize=500)

        self._sim_time = datetime.now(timezone.utc)

        # Load configs
        self._mission_cfg = load_mission_config(self.config_dir)
        self._orbit_cfg = load_orbit_config(self.config_dir)
        self._subsys_configs = load_all_subsystem_configs(self.config_dir)
        self._fdir_cfg = load_fdir_config(self.config_dir)

        # Init orbit propagator
        gs_list = []
        for gs_cfg in self._orbit_cfg.ground_stations:
            gs_list.append(GroundStation(
                name=gs_cfg.name, lat_deg=gs_cfg.lat_deg,
                lon_deg=gs_cfg.lon_deg, alt_km=gs_cfg.alt_km,
                min_elevation_deg=gs_cfg.min_elevation_deg,
            ))
        self.orbit = OrbitPropagator(
            tle_line1=self._orbit_cfg.tle_line1,
            tle_line2=self._orbit_cfg.tle_line2,
            ground_stations=gs_list,
            earth_radius_km=self._orbit_cfg.earth_radius_km,
        )

        # Instantiate subsystem models from config
        self.subsystems: dict[str, Any] = {}
        for name, cfg in self._subsys_configs.items():
            model_name = cfg.model if hasattr(cfg, 'model') else f"{name}_basic"
            try:
                model = create_model(model_name, cfg.model_dump() if hasattr(cfg, 'model_dump') else {})
                self.subsystems[name] = model
                logger.info("Loaded subsystem model: %s (%s)", name, model_name)
            except Exception as e:
                logger.warning("Failed to load model %s for %s: %s", model_name, name, e)

        # TM builder
        self.tm_builder = TMBuilder(
            apid=self._mission_cfg.spacecraft_apid,
            time_source=self._get_cuc_time,
        )

        # HK structures and timers
        self._hk_structures_raw = load_hk_structures(self.config_dir)
        self._hk_structures: dict[int, list[tuple]] = {}
        self._hk_intervals: dict[int, float] = {}
        self._hk_timers: dict[int, float] = {}
        self._hk_enabled: dict[int, bool] = {}
        for hk in self._hk_structures_raw:
            params_list = [(p.param_id, p.pack_format, p.scale) for p in hk.parameters]
            self._hk_structures[hk.sid] = params_list
            self._hk_intervals[hk.sid] = hk.interval_s
            self._hk_timers[hk.sid] = 0.0
            self._hk_enabled[hk.sid] = True

        # FDIR state
        self.sc_mode = 0  # 0=nominal, 1=safe, 2=emergency
        self._fdir_enabled = self._fdir_cfg.enabled
        self._fdir_rules = self._fdir_cfg.rules
        self._fdir_triggered: dict[str, bool] = {}

        # Transition tracking
        self._prev_in_contact = False
        self._prev_in_eclipse = False
        self._in_contact = False  # current contact state for TM gating
        self._override_passes: bool = False

        # TC Scheduler (S11)
        self._tc_scheduler = TCScheduler()

        # Onboard TM Storage (S15)
        self._tm_storage = OnboardTMStorage()

        # Subsystem event edge-detection
        self._prev_aocs_mode: Optional[int] = None
        self._prev_payload_mode: Optional[int] = None
        self._prev_obdh_mode: Optional[int] = None
        self._event_flags: dict[str, bool] = {}

        # Spacecraft phase state machine (default NOMINAL so existing tests pass)
        self._spacecraft_phase = 6   # 0=PRE_SEP,1=SEP_TIMER,2=INIT_PWR,3=BOOT,4=LEOP,5=COMM,6=NOM
        self._sep_timer = 0.0        # separation timer countdown (seconds)
        self._sep_timer_duration = 1800.0  # 30 minutes default

        # Failure manager
        from smo_simulator.failure_manager import FailureManager
        self._failure_manager = FailureManager(
            inject_fn=self._handle_failure_inject,
            clear_fn=self._handle_failure_clear,
        )

        # Service dispatcher (persistent instance for S12/S19 state)
        from smo_simulator.service_dispatch import ServiceDispatcher
        self._dispatcher = ServiceDispatcher(self)

        # Wire FDIR callbacks
        self._fdir_callbacks: dict[str, Any] = {}
        self._wire_fdir()

    def _get_cuc_time(self) -> int:
        obdh = self.subsystems.get("obdh")
        if obdh and hasattr(obdh, '_state'):
            return getattr(obdh._state, 'obc_time_cuc', 0)
        return 0

    def _wire_fdir(self) -> None:
        """Register FDIR action callbacks to subsystem methods."""
        eps = self.subsystems.get("eps")
        aocs = self.subsystems.get("aocs")
        tcs = self.subsystems.get("tcs")
        obdh = self.subsystems.get("obdh")
        payload = self.subsystems.get("payload")

        if payload:
            self._fdir_callbacks["payload_poweroff"] = lambda: payload.handle_command({"command": "set_mode", "mode": 0})
        if tcs:
            self._fdir_callbacks["heater_on_battery"] = lambda: tcs.handle_command({"command": "heater", "circuit": "battery", "on": True})
            self._fdir_callbacks["heater_off_battery"] = lambda: tcs.handle_command({"command": "heater", "circuit": "battery", "on": False})
        if aocs:
            self._fdir_callbacks["safe_mode_aocs"] = lambda: aocs.handle_command({"command": "set_mode", "mode": 2})
            for i in range(4):
                self._fdir_callbacks[f"disable_rw{i+1}"] = (lambda idx=i: aocs.handle_command({"command": "disable_wheel", "wheel": idx}))
        if obdh:
            self._fdir_callbacks["safe_mode_obc"] = lambda: obdh.handle_command({"command": "set_mode", "mode": 1})
        if eps:
            self._fdir_callbacks["safe_mode_eps"] = lambda: eps.handle_command({"command": "set_mode", "mode": 1})
        self._fdir_callbacks["spacecraft_emergency"] = lambda: setattr(self, 'sc_mode', 2)

    # ------------------------------------------------------------------
    # Spacecraft phase state machine
    # ------------------------------------------------------------------

    def _tick_spacecraft_phase(self, dt: float) -> None:
        """Manage spacecraft phase state machine.

        Phases:
        0 = PRE_SEPARATION   — everything OFF, no subsystem ticks
        1 = SEPARATION_TIMER — 30-min timer running, everything still OFF
        2 = INITIAL_POWER_ON — timer expired, unswitchable lines enable (RX + OBC)
        3 = BOOTLOADER_OPS   — OBC running bootloader, beacon HK only
        4 = LEOP             — application software booted, sequential checkout
        5 = COMMISSIONING    — all subsystems being checked out
        6 = NOMINAL          — normal operations
        """
        phase = self._spacecraft_phase

        if phase == 0:  # PRE_SEPARATION
            # Everything stays OFF, no subsystem ticks should run
            self.params[0x0129] = 0
            self.params[0x0127] = 0
            self.params[0x0128] = 0.0
            return

        elif phase == 1:  # SEPARATION_TIMER
            self._sep_timer -= dt
            self.params[0x0128] = max(0.0, self._sep_timer)
            self.params[0x0127] = 1  # timer active
            self.params[0x0129] = 1
            if self._sep_timer <= 0:
                # Timer expired — enable unswitchable power lines
                self._spacecraft_phase = 2
                self._emit_event({
                    'event_id': 0x0050,
                    'severity': 2,
                    'description': "Separation timer expired — initial power-on",
                })
            return

        elif phase == 2:  # INITIAL_POWER_ON
            # OBC and RX are on (unswitchable), everything else OFF
            # Set OBDH to bootloader mode (sw_image=0)
            obdh = self.subsystems.get("obdh")
            if obdh and hasattr(obdh, '_state'):
                obdh._state.sw_image = 0
            # Transition to bootloader ops after 1 tick
            self._spacecraft_phase = 3
            self.params[0x0129] = 2
            self._emit_event({
                'event_id': 0x0051,
                'severity': 2,
                'description': "OBC bootloader started — beacon mode",
            })
            # Fall through to let subsystems tick

        elif phase == 3:  # BOOTLOADER_OPS
            self.params[0x0129] = 3
            # Bootloader restrictions already handled by _dispatch_tc and _emit_hk_packets

        # Phases 4-6 are normal operations with increasing capability
        self.params[0x0129] = self._spacecraft_phase
        self.params[0x0127] = 0  # timer not active
        self.params[0x0128] = 0.0  # timer remaining = 0

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    @property
    def downlink_active(self) -> bool:
        """TM downlink: requires TTC link_active (orbit + transponder OK), OR override."""
        return bool(self.params.get(0x0501, 0))

    @property
    def uplink_active(self) -> bool:
        """TC uplink: requires orbital contact OR override. TTC failures don't block uplink."""
        return self._in_contact or self._override_passes

    def start(self) -> None:
        self.running = True
        self._thread = threading.Thread(target=self._run_loop, daemon=True, name="sim-engine")
        self._thread.start()
        logger.info("SimulationEngine started (speed=%.1fx)", self.speed)

    def stop(self) -> None:
        self.running = False
        logger.info("SimulationEngine stopping")

    def _run_loop(self) -> None:
        tick_hz = 1.0  # default
        dt_real = 1.0 / tick_hz
        last_wall = time.monotonic()

        while self.running:
            dt_sim = dt_real * self.speed

            # Process queues
            self._drain_instr_queue()
            self._drain_tc_queue()

            # Execute time-tagged commands from scheduler
            current_cuc = self._get_cuc_time()
            due_tcs = self._tc_scheduler.tick(current_cuc)
            for tc_pkt in due_tcs:
                self._dispatch_tc(tc_pkt)

            # Advance orbit
            orbit_state = self.orbit.advance(dt_sim)
            self._in_contact = orbit_state.in_contact
            self.params[0x05FF] = 1 if self._override_passes else 0

            # Spacecraft phase state machine (must run before subsystem ticks)
            self._tick_spacecraft_phase(dt_sim)

            # Determine which subsystems to tick based on spacecraft phase
            if self._spacecraft_phase >= 2:
                if self._spacecraft_phase < 4:
                    # Early phases: only critical subsystems (EPS, TTC, OBDH)
                    active_subsystems = {"eps", "ttc", "obdh"}
                else:
                    active_subsystems = set(self.subsystems.keys())

                for name, model in self.subsystems.items():
                    if name not in active_subsystems:
                        continue
                    try:
                        model.tick(dt_sim, orbit_state, self.params)
                    except Exception as e:
                        logger.warning("Subsystem %s tick error: %s", name, e)
            # Phases 0-1: skip ALL subsystem ticks (nothing is powered)

            # Cross-subsystem coupling
            eps = self.subsystems.get("eps")
            tcs = self.subsystems.get("tcs")
            if eps and tcs and hasattr(eps, 'set_bat_ambient_temp') and hasattr(tcs, 'get_battery_temp'):
                eps.set_bat_ambient_temp(tcs.get_battery_temp())

            # S12 on-board monitoring — check parameter limits
            self._tick_s12_monitoring()

            # FDIR
            if self._fdir_enabled:
                self._tick_fdir()

            # Subsystem event generation
            self._check_subsystem_events()

            # Transitions
            self._check_transitions(orbit_state)

            # HK emission
            self._emit_hk_packets(dt_sim)

            # Failure manager
            self._failure_manager.tick(dt_sim)

            self._tick_count += 1
            self._sim_time += timedelta(seconds=dt_sim)

            # Rate control
            elapsed = time.monotonic() - last_wall
            sleep_t = max(0.0, dt_real - elapsed)
            if sleep_t > 0:
                time.sleep(sleep_t)
            last_wall = time.monotonic()

    # ------------------------------------------------------------------
    # FDIR
    # ------------------------------------------------------------------

    def _tick_fdir(self) -> None:
        for rule in self._fdir_rules:
            param_name = rule.parameter
            threshold = rule.threshold
            if threshold is None:
                continue

            # Resolve param name to ID
            param_id = self._resolve_param_name(param_name)
            if param_id is None:
                continue

            value = self.params.get(param_id, 0.0)
            try:
                value = float(value)
            except (TypeError, ValueError):
                continue

            cond = rule.condition.strip()
            condition_met = False
            if cond.startswith("<"):
                condition_met = value < threshold
            elif cond.startswith(">"):
                condition_met = value > threshold

            rule_key = f"{param_name}_{rule.action}"
            was_triggered = self._fdir_triggered.get(rule_key, False)

            if condition_met and not was_triggered:
                self._fdir_triggered[rule_key] = True
                action = rule.action
                cb = self._fdir_callbacks.get(action)
                if cb:
                    try:
                        cb()
                    except Exception as e:
                        logger.warning("FDIR action %s error: %s", action, e)

                if rule.level >= 2 and self.sc_mode == 0:
                    self.sc_mode = 1
                if rule.level >= 3:
                    self.sc_mode = 2

                self._emit_event({
                    'event_id': 0x8000 | (param_id & 0x0FFF),
                    'severity': rule.level + 1,
                    'description': f"FDIR L{rule.level}: {action} | param={param_name} val={value:.2f}",
                })
            elif not condition_met and was_triggered:
                self._fdir_triggered[rule_key] = False

    def _resolve_param_name(self, name: str) -> Optional[int]:
        """Resolve dotted param name to param ID using subsystem configs."""
        # Simple lookup from known param_ids in subsystem configs
        parts = name.split(".", 1)
        if len(parts) != 2:
            return None
        subsys_name, param_key = parts
        cfg = self._subsys_configs.get(subsys_name)
        if cfg and hasattr(cfg, 'model_dump'):
            d = cfg.model_dump()
            pids = d.get("param_ids", {})
            return pids.get(param_key)
        return None

    # ------------------------------------------------------------------
    # TC handling
    # ------------------------------------------------------------------

    def _drain_tc_queue(self) -> None:
        while not self.tc_queue.empty():
            try:
                raw = self.tc_queue.get_nowait()
                if not self.uplink_active:
                    # Uplink not available — reject with S1.2 (error 0x0005)
                    from smo_common.protocol.ecss_packet import decommutate_packet
                    pkt = decommutate_packet(raw)
                    if pkt and pkt.primary:
                        rej = self.tm_builder.build_verification_failure(
                            pkt.primary.apid, pkt.primary.sequence_count, 0x0005)
                        self._enqueue_tm(rej)
                    continue
                self._dispatch_tc(raw)
            except queue.Empty:
                break
            except Exception as e:
                logger.warning("TC dispatch error: %s", e)

    def _check_tc_acceptance(self, service: int, subtype: int, data: bytes) -> tuple[bool, int]:
        """Validate TC before acceptance.

        Returns (accepted, error_code). Error codes:
        0x0001 = unknown service
        0x0002 = unknown subtype
        0x0003 = invalid data length
        0x0004 = subsystem power off
        """
        known_services = {3, 5, 6, 8, 9, 11, 12, 15, 17, 19, 20}
        if service not in known_services:
            return False, 0x0001

        valid_subtypes = {
            3: {1, 2, 3, 4, 5, 6, 27, 31},
            5: {5, 6, 7, 8},
            6: {2, 5, 9},
            8: {1},
            9: {1, 2},
            11: {4, 7, 9, 11, 13, 17},
            12: {1, 2, 6, 7},
            15: {1, 2, 9, 11, 13},
            17: {1},
            19: {1, 2, 4, 5, 8},
            20: {1, 3},
        }
        if service in valid_subtypes and subtype not in valid_subtypes[service]:
            return False, 0x0002

        # S8 data length check
        if service == 8 and subtype == 1 and len(data) < 1:
            return False, 0x0003

        return True, 0

    def _dispatch_tc(self, raw: bytes) -> None:
        from smo_common.protocol.ecss_packet import decommutate_packet
        pkt = decommutate_packet(raw)
        if pkt is None or pkt.secondary is None:
            return
        obdh = self.subsystems.get("obdh")
        if obdh and hasattr(obdh, 'record_tc_received'):
            obdh.record_tc_received()

        svc = pkt.secondary.service
        sub = pkt.secondary.subtype

        # Bootloader command restriction
        sw_image = int(self.params.get(0x0311, 1))
        if sw_image == 0:
            allowed = False
            if svc == 17 and sub == 1:
                allowed = True
            elif svc == 9 and sub == 1:
                allowed = True
            elif svc == 8 and sub == 1 and len(pkt.data_field) >= 1:
                func_id = pkt.data_field[0]
                if func_id in range(42, 48):  # 42-47: OBC commands
                    allowed = True
            if not allowed:
                rej = self.tm_builder.build_verification_failure(
                    pkt.primary.apid, pkt.primary.sequence_count, 0x0006)
                self._enqueue_tm(rej)
                return

        # Check acceptance
        accepted, error_code = self._check_tc_acceptance(svc, sub, pkt.data_field)
        if not accepted:
            # Send S1.2 acceptance failure
            rej = self.tm_builder.build_verification_failure(
                pkt.primary.apid, pkt.primary.sequence_count, error_code)
            self._enqueue_tm(rej)
            return

        # Send S1.1 acceptance success
        acc = self.tm_builder.build_verification_acceptance(pkt.primary.apid, pkt.primary.sequence_count)
        self._enqueue_tm(acc)

        # S1.3 Execution start
        dispatcher = self._dispatcher
        exec_start_reports = dispatcher.generate_s1_reports(
            pkt.primary.sequence_count, svc, sub)
        for rpt in exec_start_reports:
            self._enqueue_tm(rpt)

        # Check cross-subsystem power state for S8 commands

        if svc == 8 and len(pkt.data_field) >= 1:
            func_id = pkt.data_field[0]
            power_ok, reason = dispatcher.check_power_state(svc, func_id)
            if not power_ok:
                fail = self.tm_builder.build_execution_failure(
                    pkt.primary.apid, pkt.primary.sequence_count, 0x0004)
                self._enqueue_tm(fail)
                return

        # Execute
        dispatcher._last_error = None
        dispatcher._last_error_code = 0
        responses = dispatcher.dispatch(svc, sub, pkt.data_field, pkt.primary)
        for resp_pkt in responses:
            self._enqueue_tm(resp_pkt)

        # Check if dispatcher signaled an error
        if getattr(dispatcher, '_last_error', None):
            fail = self.tm_builder.build_execution_failure(
                pkt.primary.apid, pkt.primary.sequence_count,
                getattr(dispatcher, '_last_error_code', 0x0001))
            self._enqueue_tm(fail)
        else:
            # Send S1.7 execution complete
            comp = self.tm_builder.build_verification_completion(pkt.primary.apid, pkt.primary.sequence_count)
            self._enqueue_tm(comp)

        if obdh and hasattr(obdh, 'record_tc_accepted'):
            obdh.record_tc_accepted()

    # ------------------------------------------------------------------
    # HK emission
    # ------------------------------------------------------------------

    def _emit_hk_packets(self, dt_sim: float) -> None:
        # Bootloader HK gating: only emit minimal SIDs when in bootloader
        sw_image = int(self.params.get(0x0311, 1))
        for sid, interval in self._hk_intervals.items():
            if not self._hk_enabled.get(sid, True):
                continue
            if sw_image == 0 and sid not in (10, 11):
                continue
            self._hk_timers[sid] = self._hk_timers.get(sid, 0.0) + dt_sim
            if self._hk_timers[sid] >= interval:
                self._hk_timers[sid] = 0.0
                hk_struct = self._hk_structures.get(sid)
                pkt = self.tm_builder.build_hk_packet(sid, self.params, hk_structure=hk_struct)
                if pkt:
                    self._enqueue_tm(pkt)
                    obdh = self.subsystems.get("obdh")
                    if obdh and hasattr(obdh, 'record_tm_packet'):
                        obdh.record_tm_packet()

    # ------------------------------------------------------------------
    # Transitions
    # ------------------------------------------------------------------

    def _check_transitions(self, orbit_state) -> None:
        if orbit_state.in_contact and not self._prev_in_contact:
            self._emit_event({'event_id': 0x0001, 'severity': 1,
                              'description': f"AOS — elevation {orbit_state.gs_elevation_deg:.1f}°"})
        elif not orbit_state.in_contact and self._prev_in_contact:
            self._emit_event({'event_id': 0x0002, 'severity': 1, 'description': "LOS"})
        if orbit_state.in_eclipse and not self._prev_in_eclipse:
            self._emit_event({'event_id': 0x0010, 'severity': 1, 'description': "Eclipse entry"})
        elif not orbit_state.in_eclipse and self._prev_in_eclipse:
            self._emit_event({'event_id': 0x0011, 'severity': 1, 'description': "Sunlight entry"})
        self._prev_in_contact = orbit_state.in_contact
        self._prev_in_eclipse = orbit_state.in_eclipse

    def _tick_s12_monitoring(self) -> None:
        """Check S12 on-board monitoring definitions and emit events on violations."""
        violations = self._dispatcher.check_monitoring()
        for v in violations:
            self._emit_event({
                'event_id': 0x9000 | (v['param_id'] & 0x0FFF),
                'severity': 3,
                'description': (
                    f"S12 limit violation: param 0x{v['param_id']:04X} "
                    f"value={v['value']:.2f} limits=[{v['low_limit']:.2f}, {v['high_limit']:.2f}]"
                ),
            })

    def _emit_event(self, ev: dict) -> None:
        pkt = self.tm_builder.build_event_packet(
            event_id=ev.get('event_id', 0), severity=ev.get('severity', 1),
            aux_text=ev.get('description', ''), params=self.params,
        )
        if pkt:
            self._enqueue_tm(pkt)
            try:
                self.event_queue.put_nowait(ev)
            except queue.Full:
                pass

            # S19 event-action: trigger any matching event-action rules
            severity = ev.get('severity', 1)
            self._dispatcher.trigger_event_action(severity)

    def _check_subsystem_events(self) -> None:
        """Check for subsystem state transitions and emit S5 events."""
        p = self.params

        # AOCS mode change
        aocs_mode = int(p.get(0x020F, 0))
        if self._prev_aocs_mode is not None and aocs_mode != self._prev_aocs_mode:
            modes = {0: 'OFF', 1: 'DETUMBLE', 2: 'SAFE', 3: 'NADIR', 4: 'TARGET'}
            self._emit_event({
                'event_id': 0x0200,
                'severity': 2 if aocs_mode <= 2 else 1,
                'description': f"AOCS mode: {modes.get(self._prev_aocs_mode, '?')} -> {modes.get(aocs_mode, '?')}",
            })
        self._prev_aocs_mode = aocs_mode

        # Payload mode change
        payload_mode = int(p.get(0x0600, 0))
        if self._prev_payload_mode is not None and payload_mode != self._prev_payload_mode:
            modes = {0: 'OFF', 1: 'STANDBY', 2: 'IMAGING', 3: 'PLAYBACK'}
            sev = 1
            if payload_mode == 2:
                self._emit_event({
                    'event_id': 0x0600,
                    'severity': 1,
                    'description': f"Imaging started",
                })
            elif self._prev_payload_mode == 2:
                self._emit_event({
                    'event_id': 0x0601,
                    'severity': 1,
                    'description': f"Imaging stopped",
                })
            else:
                self._emit_event({
                    'event_id': 0x0602,
                    'severity': sev,
                    'description': f"Payload mode: {modes.get(self._prev_payload_mode, '?')} -> {modes.get(payload_mode, '?')}",
                })
        self._prev_payload_mode = payload_mode

        # OBDH mode change
        obdh_mode = int(p.get(0x0300, 0))
        if self._prev_obdh_mode is not None and obdh_mode != self._prev_obdh_mode:
            modes = {0: 'NOMINAL', 1: 'SAFE', 2: 'EMERGENCY'}
            self._emit_event({
                'event_id': 0x0300,
                'severity': 3 if obdh_mode >= 2 else 2 if obdh_mode == 1 else 1,
                'description': f"OBC mode: {modes.get(self._prev_obdh_mode, '?')} -> {modes.get(obdh_mode, '?')}",
            })
        self._prev_obdh_mode = obdh_mode

        # EPS threshold checks
        soc = p.get(0x0101, 75.0)
        if soc < 20 and not self._event_flags.get('low_soc_20'):
            self._event_flags['low_soc_20'] = True
            self._emit_event({
                'event_id': 0x0100,
                'severity': 4,
                'description': f"Battery SoC critical: {soc:.1f}%",
            })
        elif soc >= 22:
            self._event_flags['low_soc_20'] = False

        if soc < 30 and not self._event_flags.get('low_soc_30'):
            self._event_flags['low_soc_30'] = True
            self._emit_event({
                'event_id': 0x0101,
                'severity': 3,
                'description': f"Battery SoC low: {soc:.1f}%",
            })
        elif soc >= 32:
            self._event_flags['low_soc_30'] = False

        bus_v = p.get(0x0105, 28.0)
        if bus_v < 24.0 and not self._event_flags.get('undervoltage'):
            self._event_flags['undervoltage'] = True
            self._emit_event({
                'event_id': 0x0102,
                'severity': 4,
                'description': f"Bus undervoltage: {bus_v:.1f}V",
            })
        elif bus_v >= 25.0:
            self._event_flags['undervoltage'] = False

        # Payload storage warning
        store_pct = p.get(0x0604, 0)
        if store_pct > 90 and not self._event_flags.get('store_warn'):
            self._event_flags['store_warn'] = True
            self._emit_event({
                'event_id': 0x0603,
                'severity': 2,
                'description': f"Payload storage > 90%: {store_pct:.1f}%",
            })
        elif store_pct <= 85:
            self._event_flags['store_warn'] = False

    def _enqueue_tm(self, pkt: bytes) -> None:
        # Only downlink TM when RF link is active (orbit contact + transponder OK)
        if self.downlink_active:
            try:
                self.tm_queue.put_nowait(pkt)
            except queue.Full:
                pass
        # Always route to onboard storage regardless of contact
        if self._tm_storage and len(pkt) > 13:
            from smo_common.protocol.ecss_packet import decommutate_packet
            parsed = decommutate_packet(pkt)
            if parsed and parsed.secondary:
                self._tm_storage.store_packet(parsed.secondary.service, pkt)

    # ------------------------------------------------------------------
    # Instructor commands
    # ------------------------------------------------------------------

    def _drain_instr_queue(self) -> None:
        while not self.instr_queue.empty():
            try:
                cmd = self.instr_queue.get_nowait()
                self._handle_instructor_cmd(cmd)
            except queue.Empty:
                break

    def _handle_instructor_cmd(self, cmd: dict) -> None:
        t = cmd.get('type')
        if t == 'set_speed':
            self.speed = float(cmd.get('value', 1.0))
        elif t == 'freeze':
            self.speed = 0.0
        elif t == 'resume':
            self.speed = max(1.0, self.speed) if self.speed == 0 else self.speed
        elif t == 'inject':
            self._handle_failure_inject(cmd)
        elif t == 'clear_failure':
            self._handle_failure_clear(cmd)
        elif t == 'failure_inject':
            from smo_simulator.failure_manager import ONSET_STEP
            self._failure_manager.inject(
                subsystem=cmd.get('subsystem', ''),
                failure=cmd.get('failure', ''),
                magnitude=float(cmd.get('magnitude', 1.0)),
                onset=cmd.get('onset', ONSET_STEP),
                duration_s=float(cmd['duration_s']) if cmd.get('duration_s') else 0.0,
                onset_duration_s=float(cmd.get('onset_duration_s', 90.0)),
                **{k: v for k, v in cmd.items()
                   if k not in ('type', 'subsystem', 'failure', 'magnitude',
                                'onset', 'duration_s', 'onset_duration_s')},
            )
        elif t == 'override_passes':
            self._override_passes = bool(cmd.get('enabled', False))
        elif t == 'failure_clear':
            fid = cmd.get('failure_id')
            if fid:
                self._failure_manager.clear(fid)
            else:
                self._failure_manager.clear_all()
        elif t == 'set_phase':
            new_phase = int(cmd.get('phase', 6))
            if 0 <= new_phase <= 6:
                old_phase = self._spacecraft_phase
                self._spacecraft_phase = new_phase
                if new_phase == 1:
                    self._sep_timer = self._sep_timer_duration
                self._emit_event({
                    'event_id': 0x0052,
                    'severity': 2,
                    'description': f"Phase change: {old_phase} -> {new_phase}",
                })
        elif t == 'start_separation':
            self._spacecraft_phase = 1
            self._sep_timer = self._sep_timer_duration
            # Turn off all switchable power lines
            from smo_simulator.models.eps_basic import POWER_LINE_SWITCHABLE
            eps = self.subsystems.get("eps")
            if eps and hasattr(eps, '_state'):
                for line_name in eps._state.power_lines:
                    if POWER_LINE_SWITCHABLE.get(line_name, False):
                        eps._state.power_lines[line_name] = False
            self._emit_event({
                'event_id': 0x0053,
                'severity': 2,
                'description': "Separation initiated — 30 min timer started",
            })

    def _handle_failure_inject(self, cmd: dict) -> None:
        subsys = cmd.get('subsystem', '')
        failure = cmd.get('failure', '')
        magnitude = float(cmd.get('magnitude', 1.0))
        model = self.subsystems.get(subsys)
        if model:
            extra = {k: v for k, v in cmd.items()
                     if k not in ('type', 'subsystem', 'failure', 'magnitude')}
            model.inject_failure(failure, magnitude, **extra)

    def _handle_failure_clear(self, cmd: dict) -> None:
        subsys = cmd.get('subsystem', '')
        failure = cmd.get('failure', '')
        model = self.subsystems.get(subsys)
        if model:
            extra = {k: v for k, v in cmd.items()
                     if k not in ('type', 'subsystem', 'failure')}
            model.clear_failure(failure, **extra)

    # ------------------------------------------------------------------
    # Public accessors
    # ------------------------------------------------------------------

    def get_state_summary(self) -> dict:
        o = self.orbit.state
        p = self.params
        summary = {
            'tick': self._tick_count,
            'sim_time': self._sim_time.isoformat(),
            'speed': self.speed,
            'sc_mode': self.sc_mode,
            'in_eclipse': bool(o.in_eclipse),
            'in_contact': bool(o.in_contact),
            'lat': round(o.lat_deg, 4),
            'lon': round(o.lon_deg, 4),
            'alt_km': round(o.alt_km, 2),
            'eps': {
                'soc_pct': round(p.get(0x0101, 0), 1),
                'bat_voltage_V': round(p.get(0x0100, 0), 2),
                'bus_voltage_V': round(p.get(0x0105, 0), 2),
                'bat_temp_C': round(p.get(0x0102, 0), 1),
                'bat_current_A': round(p.get(0x0109, 0), 2),
                'sa_a_A': round(p.get(0x0103, 0), 2),
                'sa_b_A': round(p.get(0x0104, 0), 2),
                'power_gen_W': round(p.get(0x0107, 0), 1),
                'power_cons_W': round(p.get(0x0106, 0), 1),
                'power_lines': self._get_power_lines_state(),
            },
            'aocs': {
                'mode': int(p.get(0x020F, 0)),
                'att_error_deg': round(p.get(0x0217, 0), 3),
                'rate_roll': round(p.get(0x0204, 0), 4),
                'rate_pitch': round(p.get(0x0205, 0), 4),
                'rate_yaw': round(p.get(0x0206, 0), 4),
                'rw1_rpm': round(p.get(0x0207, 0)),
                'rw2_rpm': round(p.get(0x0208, 0)),
                'rw3_rpm': round(p.get(0x0209, 0)),
                'rw4_rpm': round(p.get(0x020A, 0)),
            },
            'tcs': {
                'temp_obc_C': round(p.get(0x0406, 0), 1),
                'temp_bat_C': round(p.get(0x0407, 0), 1),
                'temp_fpa_C': round(p.get(0x0408, 0), 1),
                'htr_bat': bool(p.get(0x040A, 0)),
                'htr_obc': bool(p.get(0x040B, 0)),
                'cooler_fpa': bool(p.get(0x040C, 0)),
            },
            'obdh': {
                'mode': int(p.get(0x0300, 0)),
                'cpu_load_pct': round(p.get(0x0302, 0), 1),
                'mem_used_pct': round(p.get(0x0303, 0), 1),
                'reboot_count': int(p.get(0x030A, 0)),
            },
            'ttc': {
                'mode': int(p.get(0x0500, 0)),
                'link_status': int(p.get(0x0501, 0)),
                'rssi_dBm': round(p.get(0x0502, 0), 1),
                'link_margin_dB': round(p.get(0x0503, 0), 1),
                'range_km': round(p.get(0x0509, 0), 1),
                'elevation_deg': round(p.get(0x050A, 0), 1),
            },
            'payload': {
                'mode': int(p.get(0x0600, 0)),
                'fpa_temp_C': round(p.get(0x0601, 0), 1),
                'store_used_pct': round(p.get(0x0604, 0), 1),
                'image_count': int(p.get(0x0605, 0)),
            },
            'spacecraft_phase': self._spacecraft_phase,
            'downlink_active': self.downlink_active,
            'uplink_active': self.uplink_active,
            'override_passes': self._override_passes,
            'active_failures': self._failure_manager.active_failures(),
            'scheduler': self._tc_scheduler.get_status(),
            'tm_stores': self._tm_storage.get_status(),
        }
        return summary

    def _get_power_lines_state(self) -> dict[str, bool]:
        """Get power line states from EPS model."""
        eps = self.subsystems.get("eps")
        if eps and hasattr(eps, '_state') and hasattr(eps._state, 'power_lines'):
            return dict(eps._state.power_lines)
        return {}

    def set_hk_enabled(self, sid: int, enabled: bool) -> None:
        self._hk_enabled[sid] = enabled

    def set_hk_interval(self, sid: int, interval_s: float) -> None:
        self._hk_intervals[sid] = interval_s
