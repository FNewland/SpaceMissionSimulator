"""SMO Simulator — PUS TC Service Dispatcher.

Clean class-based dispatcher. Routes incoming TC packets to appropriate
service handlers. Supports S1, S3, S5, S6, S8, S9, S11, S12, S15, S17,
S19, S20.
"""
import struct
import logging
from typing import Any

logger = logging.getLogger(__name__)


class ServiceDispatcher:
    """Dispatches PUS TC packets to service-specific handlers."""

    def __init__(self, engine):
        self._engine = engine
        self._last_error = ""
        self._last_error_code = 0

        # S1 Request Verification — enhanced subtypes
        self._s1_execution_started = False

        # S3 Housekeeping — dynamic HK definitions (for S3.1/2 create/delete)
        self._s3_custom_sids: dict[int, dict] = {}

        # S5 Event Reporting — enabled event types (set of type IDs)
        self._s5_enabled_types: set[int] = set(range(256))

        # S12 On-Board Monitoring — parameter monitoring definitions
        self._s12_definitions: dict[int, dict] = {}
        self._s12_enabled: bool = True

        # S19 Event-Action — event-action definitions
        self._s19_definitions: dict[int, dict] = {}
        self._s19_enabled_ids: set[int] = set()

    def generate_s1_reports(self, request_id: int, service: int, subtype: int
                           ) -> list[bytes]:
        """Generate S1 execution start (3/4) and progress (5/6) reports.

        Called by engine around command dispatch to provide full S1 lifecycle:
        S1.1 (accepted) → S1.3 (exec start) → S1.5 (progress) → S1.7 (completed)
        """
        reports = []
        tm = self._engine.tm_builder
        # S1.3 — Execution start success
        req_data = struct.pack('>H', request_id)
        reports.append(tm._pack_tm(service=1, subtype=3, data=req_data))
        return reports

    def generate_s1_progress(self, request_id: int, step: int) -> list[bytes]:
        """Generate S1.5 execution progress report."""
        tm = self._engine.tm_builder
        data = struct.pack('>HB', request_id, step)
        return [tm._pack_tm(service=1, subtype=5, data=data)]

    def generate_s1_exec_fail(self, request_id: int, error_code: int) -> list[bytes]:
        """Generate S1.4 execution start failure report."""
        tm = self._engine.tm_builder
        data = struct.pack('>HH', request_id, error_code)
        return [tm._pack_tm(service=1, subtype=4, data=data)]

    def dispatch(self, service: int, subtype: int, data: bytes,
                 primary_header=None) -> list[bytes]:
        """Dispatch a TC and return list of TM response packets."""
        responses = []
        try:
            if service == 3:
                responses = self._handle_s3(subtype, data)
            elif service == 5:
                responses = self._handle_s5(subtype, data)
            elif service == 6:
                responses = self._handle_s6(subtype, data)
            elif service == 8:
                responses = self._handle_s8(subtype, data)
            elif service == 9:
                responses = self._handle_s9(subtype, data)
            elif service == 11:
                responses = self._handle_s11(subtype, data)
            elif service == 12:
                responses = self._handle_s12(subtype, data)
            elif service == 15:
                responses = self._handle_s15(subtype, data)
            elif service == 17:
                responses = self._handle_s17(subtype, data)
            elif service == 19:
                responses = self._handle_s19(subtype, data)
            elif service == 20:
                responses = self._handle_s20(subtype, data)
            else:
                logger.debug("Unhandled service %d subtype %d", service, subtype)
        except Exception as e:
            logger.warning("Service %d dispatch error: %s", service, e)
        return responses

    # ─── S3 Housekeeping ─────────────────────────────────────────────
    # ECSS PUS-C subtype numbering:
    #   5 = enable periodic generation, 6 = disable, 27 = one-shot request
    #   31 = modify interval
    # Legacy subtypes 3/4/5 still accepted for backwards compatibility

    def _handle_s3(self, subtype: int, data: bytes) -> list[bytes]:
        """S3 Housekeeping requests."""
        if subtype == 1 and len(data) >= 4:
            # Create HK definition: SID(2) + interval_s(float,4) + param_count(1) + param_ids(2 each)
            sid = struct.unpack('>H', data[:2])[0]
            interval_s = struct.unpack('>f', data[2:6])[0] if len(data) >= 6 else 4.0
            param_ids = []
            offset = 7 if len(data) > 6 else 6
            count = data[6] if len(data) > 6 else 0
            for i in range(count):
                if offset + 2 <= len(data):
                    pid = struct.unpack('>H', data[offset:offset+2])[0]
                    param_ids.append(pid)
                    offset += 2
            self._s3_custom_sids[sid] = {
                'sid': sid,
                'interval_s': max(1.0, interval_s),
                'param_ids': param_ids,
            }
            self._engine.set_hk_enabled(sid, True)
            logger.info("S3 CREATE HK SID %d, interval=%.1fs, %d params",
                       sid, interval_s, len(param_ids))
        elif subtype == 2 and len(data) >= 2:
            # Delete HK definition
            sid = struct.unpack('>H', data[:2])[0]
            self._s3_custom_sids.pop(sid, None)
            self._engine.set_hk_enabled(sid, False)
            logger.info("S3 DELETE HK SID %d", sid)
        elif subtype == 27 and len(data) >= 2:
            sid = struct.unpack('>H', data[:2])[0]
            hk_struct = self._engine._hk_structures.get(sid)
            pkt = self._engine.tm_builder.build_hk_packet(
                sid, self._engine.params, hk_structure=hk_struct)
            if pkt:
                return [pkt]
        elif subtype in (3, 5) and len(data) >= 2:
            # Enable periodic HK (5 = ECSS, 3 = legacy)
            sid = struct.unpack('>H', data[:2])[0]
            self._engine.set_hk_enabled(sid, True)
        elif subtype in (4, 6) and len(data) >= 2:
            # Disable periodic HK (6 = ECSS, 4 = legacy)
            sid = struct.unpack('>H', data[:2])[0]
            self._engine.set_hk_enabled(sid, False)
        elif subtype == 31 and len(data) >= 6:
            # Modify HK interval (ECSS subtype 31)
            sid = struct.unpack('>H', data[:2])[0]
            interval_s = struct.unpack('>f', data[2:6])[0]
            self._engine.set_hk_interval(sid, max(1.0, interval_s))
        elif subtype == 5 and len(data) >= 6:
            # Legacy: subtype 5 with 6 bytes = modify interval
            sid = struct.unpack('>H', data[:2])[0]
            interval_s = struct.unpack('>f', data[2:6])[0]
            self._engine.set_hk_interval(sid, max(1.0, interval_s))
        return []

    # ─── S5 Event Reporting ──────────────────────────────────────────

    def _handle_s5(self, subtype: int, data: bytes) -> list[bytes]:
        """S5 Event Reporting — enable/disable event types."""
        if subtype == 5 and len(data) >= 1:
            # Enable event type
            event_type = data[0]
            self._s5_enabled_types.add(event_type)
        elif subtype == 6 and len(data) >= 1:
            # Disable event type
            event_type = data[0]
            self._s5_enabled_types.discard(event_type)
        elif subtype == 7:
            # Enable ALL event types
            for etype in range(1, 5):
                self._s5_enabled_types.add(etype)
        elif subtype == 8:
            # Disable ALL event types
            self._s5_enabled_types.clear()
        return []

    def is_event_enabled(self, event_type: int) -> bool:
        """Check if an event type is enabled for reporting."""
        return event_type in self._s5_enabled_types

    # ─── S6 Memory Management ────────────────────────────────────────

    def _handle_s6(self, subtype: int, data: bytes) -> list[bytes]:
        """S6 Memory Management — simplified load/dump/check."""
        responses: list[bytes] = []
        if subtype == 2 and len(data) >= 6:
            # MEM_LOAD: address(4) + data
            addr = struct.unpack('>I', data[:4])[0]
            payload_data = data[4:]
            logger.info("S6 MEM_LOAD at 0x%08X, %d bytes", addr, len(payload_data))
            # S1.5 progress for multi-step memory load
            progress = self.generate_s1_progress(0, 1)  # step 1
            responses.extend(progress)
        elif subtype == 5 and len(data) >= 6:
            # MEM_DUMP: address(4) + length(2)
            addr = struct.unpack('>I', data[:4])[0]
            length = struct.unpack('>H', data[4:6])[0]
            logger.info("S6 MEM_DUMP at 0x%08X, %d bytes", addr, length)
            # Return simulated memory content
            mem_data = struct.pack('>I', addr) + bytes(min(length, 256))
            return [self._engine.tm_builder._pack_tm(
                service=6, subtype=6, data=mem_data
            )]
        elif subtype == 9 and len(data) >= 6:
            # MEM_CHECK: address(4) + length(2)
            addr = struct.unpack('>I', data[:4])[0]
            length = struct.unpack('>H', data[4:6])[0]
            # Return checksum report
            checksum = 0xABCD  # Simulated
            resp = struct.pack('>IHH', addr, length, checksum)
            return [self._engine.tm_builder._pack_tm(
                service=6, subtype=10, data=resp
            )]
        return responses

    # ─── S8 Function Management ──────────────────────────────────────

    def _handle_s8(self, subtype: int, data: bytes) -> list[bytes]:
        """S8 Function Management — subsystem commands."""
        if subtype != 1 or len(data) < 1:
            return []
        func_id = data[0]
        # Route based on function ID ranges
        if func_id in range(0, 10):
            return self._route_aocs_cmd(func_id, data[1:])
        elif func_id in range(10, 20):
            return self._route_eps_cmd(func_id, data[1:])
        elif func_id in range(20, 30):
            return self._route_payload_cmd(func_id, data[1:])
        elif func_id in range(30, 40):
            return self._route_tcs_cmd(func_id, data[1:])
        elif func_id in range(40, 50):
            return self._route_obdh_cmd(func_id, data[1:])
        elif func_id in range(50, 60):
            return self._route_ttc_cmd(func_id, data[1:])
        return []

    def _route_aocs_cmd(self, func_id: int, data: bytes) -> list[bytes]:
        aocs = self._engine.subsystems.get("aocs")
        if not aocs:
            return []
        if func_id == 0:  # set mode
            mode = data[0] if data else 0
            aocs.handle_command({"command": "set_mode", "mode": mode})
        elif func_id == 1:  # desaturate
            aocs.handle_command({"command": "desaturate"})
        elif func_id == 2:  # disable wheel
            wheel = data[0] if data else 0
            aocs.handle_command({"command": "disable_wheel", "wheel": wheel})
        elif func_id == 3:  # enable wheel
            wheel = data[0] if data else 0
            aocs.handle_command({"command": "enable_wheel", "wheel": wheel})
        elif func_id == 4:  # ST1 power
            on = bool(data[0]) if data else True
            aocs.handle_command({"command": "st_power", "unit": 1, "on": on})
        elif func_id == 5:  # ST2 power
            on = bool(data[0]) if data else True
            aocs.handle_command({"command": "st_power", "unit": 2, "on": on})
        elif func_id == 6:  # ST select
            unit = data[0] if data else 1
            aocs.handle_command({"command": "st_select", "unit": unit})
        elif func_id == 7:  # Magnetometer select
            on = bool(data[0]) if data else True
            aocs.handle_command({"command": "mag_select", "on": on})
        elif func_id == 8:  # RW set speed bias
            if len(data) >= 5:
                wheel = data[0]
                bias = struct.unpack('>f', data[1:5])[0]
                aocs.handle_command({
                    "command": "rw_set_speed_bias", "wheel": wheel, "bias": bias
                })
        elif func_id == 9:  # MTQ enable/disable
            on = bool(data[0]) if data else True
            cmd = "mtq_enable" if on else "mtq_disable"
            aocs.handle_command({"command": cmd})
        return []

    def _route_eps_cmd(self, func_id: int, data: bytes) -> list[bytes]:
        eps = self._engine.subsystems.get("eps")
        if not eps:
            return []
        if func_id == 10:  # payload mode
            mode = data[0] if data else 0
            eps.handle_command({"command": "set_payload_mode", "mode": mode})
        elif func_id == 11:  # fpa cooler
            on = bool(data[0]) if data else False
            eps.handle_command({"command": "set_fpa_cooler", "on": on})
        elif func_id == 12:  # transponder tx
            on = bool(data[0]) if data else True
            eps.handle_command({"command": "set_transponder_tx", "on": on})
        elif func_id == 13:  # power line on
            if data:
                line_idx = data[0]
                result = eps.handle_command({
                    "command": "power_line_on", "line_index": line_idx
                })
                if not result.get("success"):
                    return self._make_error_response(result)
        elif func_id == 14:  # power line off
            if data:
                line_idx = data[0]
                result = eps.handle_command({
                    "command": "power_line_off", "line_index": line_idx
                })
                if not result.get("success"):
                    return self._make_error_response(result)
        elif func_id == 15:  # reset OC flag
            if data:
                line_idx = data[0]
                eps.handle_command({
                    "command": "reset_oc_flag", "line_index": line_idx
                })
        return []

    def _make_error_response(self, result: dict) -> list[bytes]:
        """Store error info for the engine to use in S1.8 generation."""
        self._last_error = result.get("message", "Unknown error")
        self._last_error_code = result.get("error_code", 0x0001)
        return []

    def _route_payload_cmd(self, func_id: int, data: bytes) -> list[bytes]:
        payload = self._engine.subsystems.get("payload")
        if not payload:
            return []
        if func_id == 20:  # set mode
            mode = data[0] if data else 0
            payload.handle_command({"command": "set_mode", "mode": mode})
        elif func_id == 21:  # set scene
            scene_id = (
                struct.unpack('>H', data[:2])[0] if len(data) >= 2 else 0
            )
            payload.handle_command({"command": "set_scene", "scene_id": scene_id})
        elif func_id == 22:  # capture image
            lat = 0.0
            lon = 0.0
            if len(data) >= 8:
                lat = struct.unpack('>f', data[:4])[0]
                lon = struct.unpack('>f', data[4:8])[0]
            payload.handle_command({
                "command": "capture", "lat": lat, "lon": lon
            })
        elif func_id == 23:  # download image
            scene_id = (
                struct.unpack('>H', data[:2])[0] if len(data) >= 2 else 0
            )
            payload.handle_command({
                "command": "download_image", "scene_id": scene_id
            })
        elif func_id == 24:  # delete image
            scene_id = (
                struct.unpack('>H', data[:2])[0] if len(data) >= 2 else 0
            )
            payload.handle_command({
                "command": "delete_image", "scene_id": scene_id
            })
        elif func_id == 25:  # mark bad segment
            seg = data[0] if data else 0
            payload.handle_command({
                "command": "mark_bad_segment", "segment": seg
            })
        elif func_id == 26:  # get image catalog
            payload.handle_command({"command": "get_image_catalog"})
        elif func_id == 27:  # set band configuration
            mask = data[0] if data else 0x0F
            result = payload.handle_command({
                "command": "set_band_config", "mask": mask
            })
        return []

    def _route_tcs_cmd(self, func_id: int, data: bytes) -> list[bytes]:
        tcs = self._engine.subsystems.get("tcs")
        if not tcs:
            return []
        circuits = {30: "battery", 31: "obc", 32: "thruster"}
        if func_id in circuits:
            on = bool(data[0]) if data else True
            tcs.handle_command({
                "command": "heater", "circuit": circuits[func_id], "on": on
            })
        elif func_id == 33:  # FPA cooler
            on = bool(data[0]) if data else True
            tcs.handle_command({"command": "fpa_cooler", "on": on})
        elif func_id == 34:  # Set heater setpoint
            if len(data) >= 9:
                circuit = data[0]
                on_temp = struct.unpack('>f', data[1:5])[0]
                off_temp = struct.unpack('>f', data[5:9])[0]
                tcs.handle_command({
                    "command": "set_setpoint",
                    "circuit": circuit,
                    "on_temp": on_temp,
                    "off_temp": off_temp,
                })
        elif func_id == 35:  # Auto mode
            circuit = data[0] if data else 0
            tcs.handle_command({
                "command": "auto_mode", "circuit": circuit
            })
        return []

    def _route_obdh_cmd(self, func_id: int, data: bytes) -> list[bytes]:
        obdh = self._engine.subsystems.get("obdh")
        if not obdh:
            return []
        if func_id == 40:  # set mode
            mode = data[0] if data else 0
            obdh.handle_command({"command": "set_mode", "mode": mode})
        elif func_id == 41:  # memory scrub
            obdh.handle_command({"command": "memory_scrub"})
        elif func_id == 42:  # OBC reboot
            obdh.handle_command({"command": "obc_reboot"})
        elif func_id == 43:  # OBC switch unit
            obdh.handle_command({"command": "obc_switch_unit"})
        elif func_id == 44:  # OBC select bus
            bus = data[0] if data else 0
            obdh.handle_command({"command": "obc_select_bus", "bus": bus})
        elif func_id == 45:  # OBC boot app
            obdh.handle_command({"command": "obc_boot_app"})
        elif func_id == 46:  # OBC boot inhibit
            inhibit = bool(data[0]) if data else True
            obdh.handle_command({
                "command": "obc_boot_inhibit", "inhibit": inhibit
            })
        elif func_id == 47:  # OBC clear reboot count
            obdh.handle_command({"command": "obc_clear_reboot_cnt"})
        return []

    def _route_ttc_cmd(self, func_id: int, data: bytes) -> list[bytes]:
        ttc = self._engine.subsystems.get("ttc")
        if not ttc:
            return []
        if func_id == 50:  # switch primary
            ttc.handle_command({"command": "switch_primary"})
        elif func_id == 51:  # switch redundant
            ttc.handle_command({"command": "switch_redundant"})
        elif func_id == 52:  # set tm rate
            rate = (
                struct.unpack('>I', data[:4])[0]
                if len(data) >= 4
                else 64000
            )
            ttc.handle_command({"command": "set_tm_rate", "rate": rate})
        elif func_id == 53:  # PA on
            ttc.handle_command({"command": "pa_on"})
        elif func_id == 54:  # PA off
            ttc.handle_command({"command": "pa_off"})
        elif func_id == 55:  # Set TX power
            power = (
                struct.unpack('>f', data[:4])[0]
                if len(data) >= 4
                else 2.0
            )
            ttc.handle_command({"command": "set_tx_power", "power_w": power})
        elif func_id == 56:  # Deploy antennas
            ttc.handle_command({"command": "deploy_antennas"})
        elif func_id == 57:  # Set beacon mode
            ttc.handle_command({
                "command": "set_beacon_mode",
                "on": bool(data[0]) if data else True,
            })
        elif func_id == 58:  # Start command channel
            ttc.handle_command({"command": "cmd_channel_start"})
        return []

    # ─── S9 Time Management ─────────────────────────────────────────

    def _handle_s9(self, subtype: int, data: bytes) -> list[bytes]:
        """S9 Time Management."""
        if subtype == 1 and len(data) >= 4:
            cuc = struct.unpack('>I', data[:4])[0]
            obdh = self._engine.subsystems.get("obdh")
            if obdh:
                obdh.handle_command({"command": "set_time", "cuc": cuc})
        elif subtype == 2:
            # Request time report
            cuc = self._engine._get_cuc_time()
            pkt = self._engine.tm_builder.build_time_report(cuc)
            return [pkt]
        return []

    # ─── S11 Time-tagged Scheduling ──────────────────────────────────

    def _handle_s11(self, subtype: int, data: bytes) -> list[bytes]:
        """S11 Time-tagged Command Scheduling."""
        scheduler = getattr(self._engine, '_tc_scheduler', None)
        if scheduler is None:
            return []
        if subtype == 4 and len(data) >= 4:
            exec_time = struct.unpack('>I', data[:4])[0]
            tc_pkt = data[4:]
            cmd_id = scheduler.insert(exec_time, tc_pkt)
            resp_data = struct.pack('>H', cmd_id)
            return [self._engine.tm_builder._pack_tm(
                service=11, subtype=5, data=resp_data
            )]
        elif subtype == 7 and len(data) >= 2:
            cmd_id = struct.unpack('>H', data[:2])[0]
            scheduler.delete(cmd_id)
        elif subtype == 9:
            scheduler.disable_schedule()
        elif subtype == 11:
            scheduler.delete_all()
        elif subtype == 13:
            scheduler.enable_schedule()
        elif subtype == 17:
            cmds = scheduler.list_commands()
            resp_data = struct.pack('>H', len(cmds))
            for c in cmds:
                resp_data += struct.pack('>HI', c['id'], c['exec_time'])
            return [self._engine.tm_builder._pack_tm(
                service=11, subtype=18, data=resp_data
            )]
        return []

    # ─── S12 On-Board Monitoring ─────────────────────────────────────

    def _handle_s12(self, subtype: int, data: bytes) -> list[bytes]:
        """S12 On-Board Monitoring — parameter limit checking."""
        if subtype == 1:
            # Enable monitoring
            self._s12_enabled = True
        elif subtype == 2:
            # Disable monitoring
            self._s12_enabled = False
        elif subtype == 6 and len(data) >= 10:
            # Add monitoring definition
            # Format: param_id(2) + check_type(1) + low_limit(4) + high_limit(4)
            #   check_type: 0=absolute, 1=delta
            mon_id = struct.unpack('>H', data[:2])[0]
            check_type = data[2] if len(data) > 2 else 0
            low = struct.unpack('>f', data[3:7])[0] if len(data) >= 7 else 0.0
            high = struct.unpack('>f', data[7:11])[0] if len(data) >= 11 else 0.0
            self._s12_definitions[mon_id] = {
                'param_id': mon_id,
                'check_type': check_type,
                'low_limit': low,
                'high_limit': high,
                'enabled': True,
                'last_value': None,
            }
        elif subtype == 7 and len(data) >= 2:
            # Delete monitoring definition
            mon_id = struct.unpack('>H', data[:2])[0]
            self._s12_definitions.pop(mon_id, None)
        elif subtype == 12:
            # Report all monitoring definitions
            resp_data = struct.pack('>H', len(self._s12_definitions))
            for mon_id, defn in self._s12_definitions.items():
                resp_data += struct.pack('>HBff',
                    defn['param_id'], defn.get('check_type', 0),
                    defn['low_limit'], defn['high_limit'])
            return [self._engine.tm_builder._pack_tm(
                service=12, subtype=13, data=resp_data
            )]
        return []

    def check_monitoring(self) -> list[dict]:
        """Check all monitoring definitions against current parameter values.

        Returns list of transition reports (param violations).
        Called by the engine each tick.
        """
        if not self._s12_enabled:
            return []

        violations = []
        for mon_id, defn in self._s12_definitions.items():
            if not defn.get('enabled', True):
                continue
            param_id = defn['param_id']
            value = self._engine.params.get(param_id)
            if value is None:
                continue

            low = defn['low_limit']
            high = defn['high_limit']
            if value < low or value > high:
                violations.append({
                    'param_id': param_id,
                    'value': value,
                    'low_limit': low,
                    'high_limit': high,
                    'type': 'out_of_limits',
                })

        return violations

    # ─── S15 Onboard TM Storage ──────────────────────────────────────

    def _handle_s15(self, subtype: int, data: bytes) -> list[bytes]:
        """S15 Onboard TM Storage."""
        storage = getattr(self._engine, '_tm_storage', None)
        if storage is None:
            return []
        if subtype == 1 and len(data) >= 1:
            store_id = data[0]
            storage.enable_store(store_id)
        elif subtype == 2 and len(data) >= 1:
            store_id = data[0]
            storage.disable_store(store_id)
        elif subtype == 9 and len(data) >= 1:
            store_id = data[0]
            packets = storage.start_dump(store_id)
            # Generate S1.5 progress for each batch of dump packets
            if packets:
                progress = self.generate_s1_progress(0, len(packets))
                packets.extend(progress)
            return packets
        elif subtype == 11 and len(data) >= 1:
            store_id = data[0]
            storage.delete_store(store_id)
        elif subtype == 13:
            status = storage.get_status()
            resp_data = struct.pack('>B', len(status))
            for s in status:
                resp_data += struct.pack(
                    '>BHHB',
                    s['id'], s['count'], s['capacity'],
                    1 if s['enabled'] else 0,
                )
            return [self._engine.tm_builder._pack_tm(
                service=15, subtype=14, data=resp_data
            )]
        return []

    # ─── S17 Connection Test ─────────────────────────────────────────

    def _handle_s17(self, subtype: int, data: bytes) -> list[bytes]:
        """S17 Connection Test."""
        if subtype == 1:
            pkt = self._engine.tm_builder.build_connection_test_report()
            return [pkt]
        return []

    # ─── S19 Event-Action ────────────────────────────────────────────

    def _handle_s19(self, subtype: int, data: bytes) -> list[bytes]:
        """S19 Event-Action — link events to automatic responses."""
        if subtype == 1 and len(data) >= 4:
            # Add event-action definition
            # Format: ea_id(2) + event_type(1) + action_func_id(1)
            ea_id = struct.unpack('>H', data[:2])[0]
            event_type = data[2]
            action_func_id = data[3]
            self._s19_definitions[ea_id] = {
                'event_type': event_type,
                'action_func_id': action_func_id,
            }
            self._s19_enabled_ids.add(ea_id)
        elif subtype == 2 and len(data) >= 2:
            # Delete event-action definition
            ea_id = struct.unpack('>H', data[:2])[0]
            self._s19_definitions.pop(ea_id, None)
            self._s19_enabled_ids.discard(ea_id)
        elif subtype == 4 and len(data) >= 2:
            # Enable event-action
            ea_id = struct.unpack('>H', data[:2])[0]
            if ea_id in self._s19_definitions:
                self._s19_enabled_ids.add(ea_id)
        elif subtype == 5 and len(data) >= 2:
            # Disable event-action
            ea_id = struct.unpack('>H', data[:2])[0]
            self._s19_enabled_ids.discard(ea_id)
        elif subtype == 8:
            # Report all event-action definitions
            resp_data = struct.pack('>H', len(self._s19_definitions))
            for ea_id, defn in self._s19_definitions.items():
                enabled = 1 if ea_id in self._s19_enabled_ids else 0
                resp_data += struct.pack('>HBBB',
                    ea_id, defn['event_type'], defn['action_func_id'], enabled)
            return [self._engine.tm_builder._pack_tm(
                service=19, subtype=128, data=resp_data
            )]
        return []

    def trigger_event_action(self, event_type: int) -> None:
        """Called when an event occurs — check for matching event-actions."""
        for ea_id, defn in self._s19_definitions.items():
            if ea_id not in self._s19_enabled_ids:
                continue
            if defn['event_type'] == event_type:
                func_id = defn['action_func_id']
                # Execute the S8 function
                self._handle_s8(1, bytes([func_id]))

    # ─── S20 Parameter Management ────────────────────────────────────

    def _handle_s20(self, subtype: int, data: bytes) -> list[bytes]:
        """S20 Parameter Management."""
        if subtype == 1 and len(data) >= 6:
            param_id = struct.unpack('>H', data[:2])[0]
            value = struct.unpack('>f', data[2:6])[0]
            self._engine.params[param_id] = value
        elif subtype == 3 and len(data) >= 2:
            param_id = struct.unpack('>H', data[:2])[0]
            value = float(self._engine.params.get(param_id, 0.0))
            pkt = self._engine.tm_builder.build_param_value_report(
                param_id, value
            )
            return [pkt]
        return []

    # ─── Power state checking ────────────────────────────────────────

    def check_power_state(self, service: int, func_id: int) -> tuple[bool, str]:
        """Check if the target subsystem has power before executing a command.

        Returns (allowed, reason).
        """
        eps = self._engine.subsystems.get("eps")
        if (
            not eps
            or not hasattr(eps, '_state')
            or not hasattr(eps._state, 'power_lines')
        ):
            return True, ""
        lines = eps._state.power_lines
        if service == 8 and func_id in range(20, 30):
            if not lines.get('payload', True):
                return False, "Payload power line is OFF"
        if service == 8 and func_id in range(0, 10):
            if not lines.get('aocs_wheels', True):
                return False, "AOCS wheels power line is OFF"
        return True, ""
