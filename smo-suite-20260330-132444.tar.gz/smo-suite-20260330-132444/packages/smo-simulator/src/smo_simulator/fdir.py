"""SMO Simulator — Config-driven FDIR.

FDIR is now handled directly in the SimulationEngine using config rules.
This module provides helper utilities for FDIR state tracking.
"""
from typing import Any

SC_MODE_NOMINAL = 0
SC_MODE_SAFE = 1
SC_MODE_EMERGENCY = 2


def evaluate_condition(condition: str, value: float, threshold: float) -> bool:
    """Evaluate an FDIR condition string."""
    cond = condition.strip()
    if cond.startswith("<"):
        return value < threshold
    elif cond.startswith(">"):
        return value > threshold
    elif cond.startswith("=="):
        return abs(value - threshold) < 0.001
    return False
