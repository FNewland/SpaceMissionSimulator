"""SMO Simulator — Instructor interface."""
