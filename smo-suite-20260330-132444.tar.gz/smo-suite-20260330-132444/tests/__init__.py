"""SMO test suite."""
