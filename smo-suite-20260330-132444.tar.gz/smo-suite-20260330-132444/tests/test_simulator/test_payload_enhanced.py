"""Tests for the enhanced Payload model — image catalog with capture/download/
delete, memory segment management, FPA thermal readiness, corrupted image
handling, and failure injection."""
import pytest
from unittest.mock import MagicMock

from smo_simulator.models.payload_basic import PayloadBasicModel


def make_orbit_state():
    state = MagicMock()
    state.in_eclipse = False
    state.solar_beta_deg = 20.0
    state.lat_deg = 45.0
    state.lon_deg = 10.0
    state.alt_km = 500.0
    state.vel_x = 0.0
    state.vel_y = 7.5
    state.vel_z = 0.0
    state.in_contact = False
    state.gs_elevation_deg = -10.0
    state.gs_azimuth_deg = 0.0
    state.gs_range_km = 2000.0
    return state


class TestPayloadEnhanced:
    """Enhanced Payload model tests covering image capture/download/delete,
    memory segments, FPA readiness, corruption, and new params."""

    def _make_model(self):
        """Create a configured PayloadBasicModel ready for imaging."""
        model = PayloadBasicModel()
        model.configure({"image_size_mb": 800.0, "total_storage_mb": 20000.0})
        return model

    def _make_imaging_model(self):
        """Create a model fully ready for image capture."""
        model = self._make_model()
        model._state.mode = 2  # IMAGING
        model._state.fpa_ready = True
        model._state.cooler_active = True
        model._state.fpa_temp = -5.0
        return model

    # ------------------------------------------------------------------
    # 1. Capture requires imaging mode
    # ------------------------------------------------------------------
    def test_capture_requires_imaging_mode(self):
        """In mode=0, capture should fail."""
        model = self._make_model()
        model._state.mode = 0  # OFF

        result = model.handle_command({"command": "capture"})
        assert result["success"] is False, (
            "Capture should fail when not in IMAGING mode"
        )
        assert "IMAGING" in result["message"] or "mode" in result["message"].lower(), (
            "Error message should mention mode"
        )

    # ------------------------------------------------------------------
    # 2. Capture requires FPA ready
    # ------------------------------------------------------------------
    def test_capture_requires_fpa_ready(self):
        """Set mode=2 but fpa_ready=False, capture should fail."""
        model = self._make_model()
        model._state.mode = 2  # IMAGING
        model._state.fpa_ready = False

        result = model.handle_command({"command": "capture"})
        assert result["success"] is False, (
            "Capture should fail when FPA is not ready"
        )
        assert "FPA" in result["message"] or "fpa" in result["message"].lower(), (
            "Error message should mention FPA"
        )

    # ------------------------------------------------------------------
    # 3. Capture creates image in catalog
    # ------------------------------------------------------------------
    def test_capture_creates_image_in_catalog(self):
        """Set mode=2, fpa_ready=True, enough storage, call capture.
        Verify image_catalog has 1 entry, image_count increased,
        mem_used_mb increased, last_scene_id set."""
        model = self._make_imaging_model()
        initial_image_count = model._state.image_count
        initial_mem_used = model._state.mem_used_mb

        result = model.handle_command({"command": "capture"})
        assert result["success"] is True, (
            "Capture should succeed in IMAGING mode with FPA ready"
        )
        assert len(model._state.image_catalog) == 1, (
            f"image_catalog should have 1 entry, got {len(model._state.image_catalog)}"
        )
        assert model._state.image_count == initial_image_count + 1, (
            "image_count should increase by 1 after capture"
        )
        assert model._state.mem_used_mb > initial_mem_used, (
            "mem_used_mb should increase after capture"
        )
        assert model._state.last_scene_id == result["scene_id"], (
            "last_scene_id should match the captured scene_id"
        )

    # ------------------------------------------------------------------
    # 4. Capture corrupt images
    # ------------------------------------------------------------------
    def test_capture_corrupt_images(self):
        """Inject image_corrupt with count=2, capture 3 images.
        First 2 should have status=2 (CORRUPT) with low quality,
        third should be normal."""
        model = self._make_imaging_model()

        model.inject_failure("image_corrupt", count=2)

        # Capture 3 images
        results = []
        for _ in range(3):
            result = model.handle_command({"command": "capture"})
            assert result["success"] is True
            results.append(result)

        # First 2 images should be CORRUPT (status=2)
        assert results[0]["status"] == 2, (
            "First captured image should be CORRUPT (status=2)"
        )
        assert results[0]["quality"] < 35.0, (
            "Corrupt image should have low quality"
        )
        assert results[1]["status"] == 2, (
            "Second captured image should be CORRUPT (status=2)"
        )
        assert results[1]["quality"] < 35.0, (
            "Corrupt image should have low quality"
        )

        # Third image should be normal (status=0)
        assert results[2]["status"] == 0, (
            "Third captured image should be OK (status=0) after corrupt count exhausted"
        )

    # ------------------------------------------------------------------
    # 5. Capture with CCD line dropout
    # ------------------------------------------------------------------
    def test_capture_with_ccd_line_dropout(self):
        """Inject ccd_line_dropout, capture. Verify status=1 (PARTIAL)
        and quality < 90."""
        model = self._make_imaging_model()

        model.inject_failure("ccd_line_dropout")

        result = model.handle_command({"command": "capture"})
        assert result["success"] is True
        assert result["status"] == 1, (
            "Image with CCD line dropout should have status=1 (PARTIAL)"
        )
        assert result["quality"] < 90.0, (
            f"Image quality with CCD line dropout should be < 90, got {result['quality']}"
        )

    # ------------------------------------------------------------------
    # 6. Download image
    # ------------------------------------------------------------------
    def test_download_image(self):
        """Capture an image, then download_image with that scene_id.
        Verify success and image data returned."""
        model = self._make_imaging_model()

        # Capture an image
        capture_result = model.handle_command({"command": "capture"})
        assert capture_result["success"] is True
        scene_id = capture_result["scene_id"]

        # Download it
        dl_result = model.handle_command({
            "command": "download_image",
            "scene_id": scene_id,
        })
        assert dl_result["success"] is True, (
            "download_image should succeed for existing scene_id"
        )
        assert "image" in dl_result, (
            "download result should contain 'image' key"
        )
        assert dl_result["image"]["scene_id"] == scene_id, (
            "Downloaded image scene_id should match requested scene_id"
        )

    # ------------------------------------------------------------------
    # 7. Download non-existent image
    # ------------------------------------------------------------------
    def test_download_nonexistent_image(self):
        """download_image with non-existent scene_id, verify failure."""
        model = self._make_imaging_model()

        result = model.handle_command({
            "command": "download_image",
            "scene_id": 99999,
        })
        assert result["success"] is False, (
            "download_image should fail for non-existent scene_id"
        )
        assert "not found" in result["message"].lower(), (
            "Error message should indicate image not found"
        )

    # ------------------------------------------------------------------
    # 8. Delete image by scene_id
    # ------------------------------------------------------------------
    def test_delete_image_by_scene_id(self):
        """Capture, then delete_image with scene_id. Verify catalog is empty,
        image_count decreased, mem_used_mb decreased."""
        model = self._make_imaging_model()

        # Capture an image
        capture_result = model.handle_command({"command": "capture"})
        scene_id = capture_result["scene_id"]
        count_after_capture = model._state.image_count
        mem_after_capture = model._state.mem_used_mb

        # Delete it
        del_result = model.handle_command({
            "command": "delete_image",
            "scene_id": scene_id,
        })
        assert del_result["success"] is True, (
            "delete_image should succeed for existing scene_id"
        )
        assert len(model._state.image_catalog) == 0, (
            "image_catalog should be empty after deleting the only image"
        )
        assert model._state.image_count == count_after_capture - 1, (
            "image_count should decrease by 1 after delete"
        )
        assert model._state.mem_used_mb < mem_after_capture, (
            "mem_used_mb should decrease after deleting image"
        )

    # ------------------------------------------------------------------
    # 9. Mark bad segment
    # ------------------------------------------------------------------
    def test_mark_bad_segment(self):
        """mark_bad_segment(segment=0), verify bad_segments=[0],
        mem_segments_bad=1, mem_total_mb decreased."""
        model = self._make_model()
        initial_total = model._state.mem_total_mb

        result = model.handle_command({
            "command": "mark_bad_segment",
            "segment": 0,
        })
        assert result["success"] is True
        assert 0 in model._state.bad_segments, (
            "Segment 0 should be in bad_segments"
        )
        assert model._state.mem_segments_bad == 1, (
            "mem_segments_bad should be 1"
        )
        assert model._state.mem_total_mb < initial_total, (
            "mem_total_mb should decrease after marking a segment bad"
        )

    # ------------------------------------------------------------------
    # 10. Mark bad segment with invalid index
    # ------------------------------------------------------------------
    def test_mark_bad_segment_invalid(self):
        """mark_bad_segment with out-of-range segment, verify failure."""
        model = self._make_model()

        # Segment index too high
        result = model.handle_command({
            "command": "mark_bad_segment",
            "segment": 999,
        })
        assert result["success"] is False, (
            "mark_bad_segment should fail for out-of-range segment index"
        )

        # Negative segment index
        result = model.handle_command({
            "command": "mark_bad_segment",
            "segment": -1,
        })
        assert result["success"] is False, (
            "mark_bad_segment should fail for negative segment index"
        )

    # ------------------------------------------------------------------
    # 11. Get image catalog
    # ------------------------------------------------------------------
    def test_get_image_catalog(self):
        """Capture 2 images, get_image_catalog, verify count=2."""
        model = self._make_imaging_model()

        model.handle_command({"command": "capture"})
        model.handle_command({"command": "capture"})

        result = model.handle_command({"command": "get_image_catalog"})
        assert result["success"] is True
        assert result["count"] == 2, (
            f"get_image_catalog should report count=2, got {result['count']}"
        )
        assert len(result["catalog"]) == 2, (
            f"Catalog should have 2 entries, got {len(result['catalog'])}"
        )

    # ------------------------------------------------------------------
    # 12. Capture fails with insufficient storage
    # ------------------------------------------------------------------
    def test_capture_fails_insufficient_storage(self):
        """Set mem_used_mb to near total, capture should fail with
        'Insufficient storage'."""
        model = self._make_imaging_model()

        # Fill up storage so available < image_size_mb (800)
        model._state.mem_used_mb = model._state.mem_total_mb - 100.0

        result = model.handle_command({"command": "capture"})
        assert result["success"] is False, (
            "Capture should fail when insufficient storage is available"
        )
        assert "storage" in result["message"].lower() or "Insufficient" in result["message"], (
            "Error message should mention insufficient storage"
        )

    # ------------------------------------------------------------------
    # 13. Memory segment fail injection
    # ------------------------------------------------------------------
    def test_memory_segment_fail_injection(self):
        """Inject memory_segment_fail on segment 2, verify bad_segments=[2],
        mem_total_mb decreased."""
        model = self._make_model()
        initial_total = model._state.mem_total_mb

        model.inject_failure("memory_segment_fail", segment=2)

        assert 2 in model._state.bad_segments, (
            "Segment 2 should be in bad_segments after injection"
        )
        assert model._state.mem_segments_bad == 1, (
            "mem_segments_bad should be 1 after failing one segment"
        )
        assert model._state.mem_total_mb < initial_total, (
            "mem_total_mb should decrease after memory_segment_fail injection"
        )

    # ------------------------------------------------------------------
    # 14. FPA ready when cooled
    # ------------------------------------------------------------------
    def test_fpa_ready_when_cooled(self):
        """Set fpa_temp to well below target + 5, verify fpa_ready = True
        after tick."""
        model = self._make_model()
        model._state.mode = 1  # STANDBY (cooler on)
        model._state.cooler_active = True
        model._state.fpa_temp = -10.0  # Well below target (-5) + 5 = 0

        orbit = make_orbit_state()
        params = {}
        model.tick(1.0, orbit, params)

        assert model._state.fpa_ready is True, (
            "fpa_ready should be True when fpa_temp is well below target + 5"
        )

    # ------------------------------------------------------------------
    # 15. FPA not ready when warm
    # ------------------------------------------------------------------
    def test_fpa_not_ready_when_warm(self):
        """Set fpa_temp to 20 (above target + 5), verify fpa_ready = False
        after tick."""
        model = self._make_model()
        model._state.mode = 1  # STANDBY
        model._state.cooler_active = True
        model._state.fpa_temp = 20.0  # Above target (-5) + 5 = 0

        orbit = make_orbit_state()
        params = {}
        model.tick(1.0, orbit, params)

        assert model._state.fpa_ready is False, (
            "fpa_ready should be False when fpa_temp (20) is above target + 5 (0)"
        )

    # ------------------------------------------------------------------
    # 16. New params written to shared_params
    # ------------------------------------------------------------------
    def test_new_params_written(self):
        """Tick, verify new params 0x060A, 0x060B, 0x060C, 0x060D,
        0x0610, 0x0612, 0x0613 all exist in shared_params."""
        model = self._make_model()
        orbit = make_orbit_state()
        params = {}

        model.tick(1.0, orbit, params)

        expected_params = [
            0x060A,  # mem_total_mb
            0x060B,  # mem_used_mb
            0x060C,  # last_scene_id
            0x060D,  # last_scene_quality
            0x0610,  # fpa_ready
            0x0612,  # mem_segments_bad
            0x0613,  # duty_cycle_pct
        ]
        for addr in expected_params:
            assert addr in params, (
                f"Param 0x{addr:04X} missing from shared_params"
            )
